import * as types from '@/constants/actionType'
import http from '@/helpers/apiCaller'
import actionResponse from '@/helpers/actionResponse'

export const actLogin = (params) => {
    return async (dispatch) => {
        let result
        try{
            let response = await http.post('api/login', params)
            localStorage.setItem('token', response.data.token);
            result = actionResponse.format(response, types.LOGIN);
        }
        catch(e){
            result.data = actionResponse.format(e.response, types.LOGIN);
        }
        dispatch(result)
    }
}
export const actFetch = (params) => {
    return async (dispatch) => {
        let result;
        try{
            let response = await http.get('api/users/' + params._id)
            result = actionResponse.format(response, types.USER_FETCH);
        }
        catch(e){
            result = actionResponse.format(e.response, types.USER_FETCH);
        }
        dispatch(result)
    }
}

export const actFetchAll = (params) => {
    return async (dispatch) => {
        let result;
        try{
            let response = await http.get('api/users/',params)
            result = actionResponse.format(response, types.USER_FETCH_ALL);
        }
        catch(e){
            result = actionResponse.format(e.response, types.USER_FETCH_ALL);
        }
        dispatch(result)
    }
}

export const actEdit = (params) => {
    return async (dispatch) => {
        let result;
        try{
            let response = await http.put('api/users/' + params._id, params)
            result = actionResponse.format(response, types.USER_EDIT);
        }
        catch(e){
            result = actionResponse.format(e.response, types.USER_EDIT);
    }
        dispatch(result)
    }
}
