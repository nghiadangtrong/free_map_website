import React, {Component} from 'react';
import {Container, Row, Col, CardGroup, Card, CardBody, Button, Input, InputGroup, InputGroupAddon, InputGroupText} from 'reactstrap';
import { connect } from 'react-redux';
import { bindActionCreators } from 'redux';
import * as usersActions from '@/actions/usersActions';

import {Redirect} from 'react-router-dom';
//import UserService from '@/services/UserService'
import InputModel from '@/helpers/InputModel'

class Login extends Component {
	constructor(props) {
		super(props);
		this.state = {
			form: {
				code: ''
			},
			loggedIn: false
		}
	}
	componentDidMount() {
		// Gọi trước khi component đc render lần đầu tiên
		//this.props.fetchAllProducts();
	}
	//khi có thay đổi về props, sẽ gọi vào hàm này trước khi Update component
	componentWillUpdate(nextProps){
		/* if(nextProps.users !== this.props.users){
			console.log(nextProps.users)
		} */
	}
	//khi có thay đổi về props, sẽ gọi vào hàm này sau khi Update component
	componentDidUpdate(prevProps){
        //kiếm tra store users có thay đổi
		if(prevProps.users !== this.props.users){
			this.afterLogin();
		}
	}
	login(){
		let data = this.state.form
		this.props.onLogin(data)
	}
	afterLogin(){
		const { from } = this.props.location.state || { from: { pathname: '/' } }
		let {users} = this.props
		if(users.data.token){
			this.props.history.push(from)
		}
	}
  	render() {
		const _InputModel = InputModel(this)
		return (
		<div className="app flex-row align-items-center">
			<Container>
			<Row className="justify-content-center">
				<Col md="8">
				<CardGroup>
					<Card className="p-4">
					<CardBody>
						<h1>Login</h1>
						<p className="text-muted">Sign In to your account</p>
						<InputGroup className="mb-3">
						<InputGroupAddon addonType="prepend">
							<InputGroupText>
							<i className="icon-user"></i>
							</InputGroupText>
						</InputGroupAddon>
						<Input type="text" placeholder="Username" {..._InputModel('form.code')}/>
						</InputGroup>
						<InputGroup className="mb-4">
						<InputGroupAddon addonType="prepend">
							<InputGroupText>
							<i className="icon-lock"></i>
							</InputGroupText>
						</InputGroupAddon>
						<Input type="password" placeholder="Password" {..._InputModel('form.password')}/>
						</InputGroup>
						<Row>
						<Col xs="6">
							<Button color="primary" className="px-4" onClick={this.login.bind(this)}>Login</Button>
						</Col>
						<Col xs="6" className="text-right">
							<Button color="link" className="px-0">Forgot password?</Button>
						</Col>
						</Row>
					</CardBody>
					</Card>
					<Card className="text-white bg-primary py-5 d-md-down-none" style={{ width: 44 + '%' }}>
					<CardBody className="text-center">
						<div>
						<h2>Sign up</h2>
						<p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut
							labore et dolore magna aliqua.</p>
						<Button color="primary" className="mt-3" active>Register Now!</Button>
						</div>
					</CardBody>
					</Card>
				</CardGroup>
				</Col>
			</Row>
			</Container>
		</div>
		);
  }
}
const mapStateToProps = state => {
	return {
		users: state.users
	}
}

const mapDispatchToProps = (dispatch, props) => {
	return {
		onLogin: (params) => {
			dispatch(usersActions.actLogin(params));
		}
	}
}
export default connect(mapStateToProps, mapDispatchToProps)(Login);
