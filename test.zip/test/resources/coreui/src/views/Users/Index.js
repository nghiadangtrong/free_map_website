import React, {Component} from 'react';
import {
    Row,
    Col,
    Button,
    ButtonDropdown,
    DropdownToggle,
    DropdownMenu,
    DropdownItem,
    Card,
    CardHeader,
    CardFooter,
    CardBody,
    Collapse,
    Form,
    FormGroup,
    FormText,
    Label,
    Input,
    InputGroup,
    InputGroupAddon,
    InputGroupText
} from 'reactstrap';
import {Redirect, withRouter} from 'react-router-dom';
import { connect } from 'react-redux';
import { bindActionCreators } from 'redux';
import {Translate, Localize, I18n} from 'react-redux-i18n'
import * as usersActions from '@/actions/usersActions';
import Swal from 'sweetalert2'
import BootstrapTableNext from '@/components/Table/BootstrapTableNext'
import filterFactory, { textFilter } from 'react-bootstrap-table2-filter';
class Index extends Component {
    constructor(props) {
        super(props);
        this.state = {
            columns: [ //khai báo các cột cho table
                {
                    dataField: 'id', //trên trường dữ liệu tương ứng trong data response
                    'text': I18n.t("users.id") //Text hiển thị lên head của cột
                },
                {
                    dataField: 'code',
                    'text': I18n.t("users.code"),
                    filter: textFilter() //filter của table. tham khảo https://www.npmjs.com/package/react-bootstrap-table2-filter
                },
                {
                    dataField: 'name',
                    'text': I18n.t("users.name"),
                    filter: textFilter()
                },
            ]
        }
    }
    async componentDidMount(){
        this.props.onChange({})
    }
    componentDidUpdate(prevProps){
        let {users} = this.props
        if(prevProps.users != users){
            if(users.success == false){
              Swal("Oops...",users.error,"error")
            }
        }
    }
    onTableChange(type, newState){
        this.props.onChange(newState)
    }

    render() {
        const {users} = this.props
        const {columns, paginationOption} = this.state
        const userData = users.data || {}
        let {data, page, perPage, total} = userData //lấy lại các giá trị từ server gửi về trong request (lấy trong redux)
        return (
            <div className="animated fadeIn">
                <Row>
                    <Col xs="12" sm="12">
                        <Card>
                            <CardHeader>
                                <strong><Translate value="users.index_title"/></strong>
                            </CardHeader>
                            <CardBody>
                                <BootstrapTableNext
                                    keyField = '_id'
                                    data = { data }
                                    page = { page }
                                    sizePerPage = { perPage }
                                    totalSize = { total }
                                    columns={ columns }
                                    pagination ={ paginationOption }
                                    onTableChange = { (type, newState) => (this.onTableChange(type, newState))}
                                 />
                            </CardBody>
                        </Card>
                    </Col>
                </Row>
            </div>
        );
    }
}

const mapStateToProps = state => {
        return {
                users: state.users
        }
}

const mapDispatchToProps = (dispatch, props) => {
    return {
        onChange: (params) =>{
            dispatch(usersActions.actFetchAll(params));
        }
    }
}
export default withRouter(connect(mapStateToProps, mapDispatchToProps)(Index));
