import React,{Component} from 'react'
import {Translate, Localize, I18n} from 'react-redux-i18n'
import {
    Row,
    Col,
    Button,
    ButtonDropdown,
    DropdownToggle,
    DropdownMenu,
    DropdownItem,
    Card,
    CardHeader,
    CardFooter,
    CardBody,
    Collapse,
    Form,
    FormGroup,
    FormText,
    Label,
    Input,
    InputGroup,
    InputGroupAddon,
    InputGroupText
  } from 'reactstrap';

import { connect } from 'react-redux';
import { bindActionCreators } from 'redux';
import { Field, reduxForm } from 'redux-form'
import {renderTextField, renderDropdown, Validate, Normalize} from '@/helpers/Form'
import { DropdownList } from 'react-widgets'
class EditForm extends Component{
	constructor(){
		super()
		//khai báo các hàm validate, bắt buộc phải khai báo trong constructor, tránh việc render lại nhiều lần
		this.state = {
			validateForm: {
				required: 	Validate.required(I18n.t("form.required")),
				maxlength15:Validate.maxLength(15,I18n.t("form.maxlength15")),
				minLength2: Validate.minLength(2,I18n.t("form.minlength2"))
			},
			roles: [
				{value: "admin", text: "admin"},
				{value: "employee", text: "employee"}
			]
		}
	}
	componentDidMount(){

	}
	fieldsConfig(){
		const {validateForm, roles} = this.state
		return {
			fields:{
				code:{
					type: 		 "text", //kiểu dữ liệu của input
					name:		 "code", //tên input
					label: 		 I18n.t("users.code"), //Text hiển thị phía trên của input
					placeholder: I18n.t("users.code_placeholder"), //placeholder
					component: renderTextField, //component để render ra input
					validate:[ //validate input, tham khảo tại @/helpers/Form.js
						validateForm.required,
						validateForm.maxlength15,
						validateForm.minLength2
					],
					normalize: Normalize.upper() //format lại dữ liệu khi nhập vào input
				},
				name:{
					type: 		 "text", //kiểu dữ liệu của input
					name:		 "name", //tên input
					label: 		 I18n.t("users.name"), //Text hiển thị phía trên của input
					placeholder: I18n.t("users.name_placeholder"), //placeholder
					component: renderTextField, //component để render ra input
					validate:[ //validate input, tham khảo tại @/helpers/Form.js
						validateForm.required,
						validateForm.maxlength15,
						validateForm.minLength2
					]
				},
				role:{
					type: 		 "role", //kiểu dữ liệu của input
					filter: 	 true,

					clsss: "form-control",
					name:		 "roles", //tên input
					label: 		 I18n.t("users.role"), //Text hiển thị phía trên của input
					placeholder: I18n.t("users.role_placeholder"), //placeholder
					component: renderDropdown, //component để render ra input,
					valueField: "value",
					textField: "text",
					data: [
						{value: "admin", text: "admin"},
						{value: "employee", text: "employee"}
					],
					validate:[ //validate input, tham khảo tại @/helpers/Form.js
						validateForm.required
					],
				},
				user_barcode:{
					type: 		 "text", //kiểu dữ liệu của input
					name:		 "user_barcode", //tên input
					label: 		 I18n.t("users.barcode"), //Text hiển thị phía trên của input
					placeholder: I18n.t("users.barcode_placeholder"), //placeholder
					component: renderTextField, //component để render ra input
					validate:[ //validate input, tham khảo tại @/helpers/Form.js
						validateForm.required,
						validateForm.maxlength15,
						validateForm.minLength2
					]
				}
			}
		}
	}
	render(){
		const { handleSubmit } = this.props
		const {fields} = this.fieldsConfig()
		return (
			<div className="animated fadeIn">
				<Form onSubmit={handleSubmit}>
					<Row>
						<Col xs="12">
							<Field {...fields.code} />
						</Col>
					</Row>
					<Row>
						<Col xs="12">
							<Field {...fields.name} />
						</Col>
					</Row>
					<Row>
						<Col xs="12">
						<FormGroup>
					<Field  {...fields.role} />
				</FormGroup>
						</Col>
					</Row>
					<Row>
						<Col xs="12">
							<Field {...fields.user_barcode} />
						</Col>
					</Row>
					<Row>
						<Col xs="12">
						<Button color="primary">{I18n.t("users.save")}</Button>
						</Col>
					</Row>
				</Form>
			</div>
		)
	}
}

EditForm = reduxForm({
  // a unique name for the form
  form: 'user.edit.form'
})(EditForm)
const mapStateToProps = state => {
	return {
		initialValues: state.users.data
	}
}
const mapDispatchToProps = (dispatch, props) => {
    return {

    }
}
export default connect(mapStateToProps, mapDispatchToProps)(EditForm);
