import React from 'react'
import {
    Row,
    Col,
    Button,
    ButtonDropdown,
    DropdownToggle,
    DropdownMenu,
    DropdownItem,
    Card,
    CardHeader,
    CardFooter,
    CardBody,
    Collapse,
    Form,
    FormGroup,
    FormText,
    Label,
    Input,
    InputGroup,
    InputGroupAddon,
    InputGroupText
  } from 'reactstrap';
  
import { Field, reduxForm } from 'redux-form'

let CreateForm = props => {
  const { handleSubmit } = props
  return (
	<div className="animated fadeIn">
		 <Form onSubmit={handleSubmit}>
			<Row>
				<Col xs="12">
					<FormGroup>
						<Label htmlFor="name">Code</Label>
						<Field className="form-control" placeholder="Enter your code" name="code" component="input" type="text" />
					</FormGroup>
				</Col>
			</Row>
			<Row>
				<Col xs="12">
				<FormGroup>
					<Label htmlFor="ccnumber">Name</Label>
					<Field className="form-control"  name="name" component="input" type="text" />
				</FormGroup>
				</Col>
			</Row>
			<Row>
				<Col xs="12">
				<FormGroup>
					<Label htmlFor="ccmonth">Roles</Label>
					<Field className="form-control"  name="_roles" component="select" type="text" />
				</FormGroup>
				</Col>
			</Row>
			<Row>
				<Col xs="12">
				<FormGroup>
					<Label htmlFor="password">Password</Label>
					<Field className="form-control"  name="password" component="input" type="text" />
				</FormGroup>
				<Button color="primary">Save</Button>
				</Col>
			</Row>
		</Form>
	</div>
  )
}

CreateForm = reduxForm({
  // a unique name for the form
  form: 'user.create.form'
})(CreateForm)

export default CreateForm