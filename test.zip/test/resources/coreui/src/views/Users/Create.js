import React, {Component} from 'react';
import {
    Row,
    Col,
    Button,
    ButtonDropdown,
    DropdownToggle,
    DropdownMenu,
    DropdownItem,
    Card,
    CardHeader,
    CardFooter,
    CardBody,
    Collapse,
    Form,
    FormGroup,
    FormText,
    Label,
    Input,
    InputGroup,
    InputGroupAddon,
    InputGroupText
  } from 'reactstrap';
import {Redirect} from 'react-router-dom';
import { connect } from 'react-redux';
import { bindActionCreators } from 'redux';
import * as usersActions from '@/actions/usersActions';

import InputModel from '@/helpers/InputModel'

/* import BootstrapTable from 'react-bootstrap-table-next';
import paginationFactory from 'react-bootstrap-table2-paginator';
import cellEditFactory from 'react-bootstrap-table2-editor'; */
import Swal from 'sweetalert2'

//import 'react-bootstrap-table-next/dist/react-bootstrap-table2.min.css';
//import 'react-bootstrap-table2-paginator/dist/react-bootstrap-table2-paginator.min.css';
import CreateForm from './components/create.form'

class Create extends Component {
	constructor(props) {
      super(props);     
      this.state = {
        code: '',
        name: '',
        roles: ['employee'],
        _roles: '',
        password: '',
        
        alertShow: false,
        alertTitle: '',
        alertText: ''
      }
  }
  async componentDidMount(){
	
  }

  submit(values ){
	  console.log(values )
  }

  render() {
    const _InputModel = InputModel(this)
    return (
      <div className="animated fadeIn">
        <Row>
          <Col xs="12" sm="12">
            <Card>
              <CardHeader>
                <strong>Create User</strong>
              </CardHeader>
              <CardBody>
					<CreateForm onSubmit={this.submit.bind(this)} />
              </CardBody>
            </Card>
          </Col>
        </Row>
      </div>
    );
  }
}

const mapStateToProps = state => {
	return {
		users: state.users
	}
}

const mapDispatchToProps = (dispatch, props) => {
	return {
		onLogin: (params) => {
			dispatch(usersActions.actLogin(params));
		}
	}
}
export default connect(mapStateToProps, mapDispatchToProps)(Create);