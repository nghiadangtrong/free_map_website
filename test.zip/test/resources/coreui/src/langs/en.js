export const en = {
	form:{
		required: "Required!"
	}
}