import {vi} from './vi'
import {en} from './en'

export default {
	vi: vi,
	en: en,
}