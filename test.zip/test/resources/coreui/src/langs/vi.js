export const vi = {
	form:{
		required: "Trường bắt buộc nhập",
		maxlength15: "Chỉ được nhập tối đa 15 ký tự",
		minlength2: "Nhập ít nhất 2 ký tự"
	},
	users:{
		breadcrumbs:{
			index: 	"Người dùng",
			add: 	"Thêm người dùng",
			edit:	"Sửa thông tin người dùng",
    },
    index_title: "Danh sách người dùng",
		add_title:"Thêm người dùng",
    edit_title:"Sửa người dùng",

    id: "ID",
		code: "Mã số",
		code_placeholder: "Nhập mã số người dùng",
		name: "Tên",
		name_placeholder: "Nhập tên người dùng",
		role: "Quyền hạn",
		role_placeholder: "Chọn quyền hạn",
		password: "Mật khẩu",
		password_placeholder: "Nhập mật khẩu",
		barcode: "Mã barcode",
		barcode_placeholder: "Nhập mã barcode nhân viên",
		save: "Lưu lại"
	}
}
