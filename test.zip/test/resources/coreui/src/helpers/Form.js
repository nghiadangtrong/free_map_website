import React from 'react'
import {
    DropdownToggle,
    DropdownMenu,
    DropdownItem,
    FormGroup,
	FormText,
	FormFeedback,
    Label,
    Input,
    InputGroup,
    InputGroupAddon,
    InputGroupText
  } from 'reactstrap';
import { Field } from 'redux-form'
import DropdownList from 'react-widgets/lib/DropdownList';
export const renderTextField = ({
	input,
	label,
	placeholder,
	type,
	meta: { touched, error, warning }
}) => (
	<FormGroup>
		<Label>{label}</Label>
		<Input {...input} placeholder={placeholder} type={type} 
		{...(touched? {valid: !(touched && (error || warning))}: "" )}  />
		<FormFeedback>{error || warning}</FormFeedback>
			</FormGroup>
)
export const renderDropdown = ({
	input,
	label,
	placeholder,
	meta: { touched, error, warning },
	...args
}) => {
	return (
	<FormGroup>
		<Label>{label}</Label>
		<DropdownList {...input} placeholder={placeholder} onChange={input.onChange} {...args} value={input.value || args.defaultValue || input.value[0]}
		 className={touched? (error || warning) ? "is-invalid form-control": "is-valid form-control": ""} />
		<FormFeedback>{error || warning}</FormFeedback>
	</FormGroup>
	)
}

export const renderOtherField = ({
	input,
	label,
	placeholder,
	render,
	type,
	meta: { touched, error, warning },
	...args
}) => (
	<FormGroup>
		<Label>{label}</Label>
		<Field component={render} {...input} placeholder={placeholder} type={type} {...args}  />
		{touched && ((error && <span>{error}</span>) || (warning && <span>{warning}</span>))}
	</FormGroup>
)

export class Validate {
	static required(message){
		return (value) => {
			return value ? undefined : message
		}
	}
	static maxLength(max, message){
		return (value) => {
			return value && value.length > max ? message : undefined
		}
	}
	static minLength(min, message){
		return (value) => {
			return value && value.length < min ? message : undefined
		}
	}
	static isNumber(message){
		return (value) => {
			return  value && isNaN(Number(value)) ? message : undefined
		}
	}
	static max(max, message){
		return (value) => {
			return value && value > max ? message : undefined
		}
	}
	static min(min, message){
		return (value) => {
			return value && value < min ? message : undefined
		}
	}
}

export class Normalize{
	static upper(){
		return (value) =>{
			return value && value.toUpperCase()
		}
	}
	static lower(){
		return (value) =>{
			return value && value.toLowerCase()
		}
	}
	static lessThanField(otherField){
		return (value, previousValue, allValues) =>{
			return parseFloat(value) < parseFloat(allValues[otherField]) ? value : previousValue
		}
	}
	static greaterThanField(otherField){
		return (value, previousValue, allValues) =>{
			return parseFloat(value) > parseFloat(allValues[otherField]) ? value : previousValue
		}
	}
}