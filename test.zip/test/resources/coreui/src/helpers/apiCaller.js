import axios from 'axios';
import * as config from '../constants/config.js'
class ApiCaller{
	static init(){
		let token = localStorage.getItem('token')
		axios.defaults.headers.common['Authorization'] = `Bearer ${token}`;
	}
	static getAppUrl(){
		return process.env.HTTP_METHOD + "://" + process.env.HOST + ":" +process.env.PORT + "/"
	}
	static async get(url, data = {}){
		this.init()
		let result = await axios.get(this.getAppUrl() + url,{
            params: data
          });
		return result
	}
	static async post(url, data){
		this.init()
		let result = await axios.post(this.getAppUrl() + url, data);
		return result
	}
	static async put(url, data){
		this.init()
		let result = await axios.put(this.getAppUrl() + url, data);
		return result
	}
	static async delete(url){
		this.init()
		let result = await axios.delete(this.getAppUrl() + url);
		return result
	}

}

export default ApiCaller;
