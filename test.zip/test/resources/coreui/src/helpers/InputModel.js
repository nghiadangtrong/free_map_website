/**
 * 
 * @param {*} context
 * sử dụng để làm 2 way bind cho form, khai báo bindModel(this)
 * sử dụng:
 * <Input type="text" {..._InputModel('username')}/>
 */
import _ from 'lodash'
export default function bindModel(context) {
	return function(key) {
	  return {
		value: context.state[key],
		checked: context.state[key],
  
		onChange(event) {
		  	const target = event.target;
		  	const value = target.type === 'checkbox' ? target.checked : target.value;

			let obj = Object.assign({}, context.state)
			_.setWith(obj,key,value)
			context.setState(obj);
		  if (typeof context.handleChange === 'function') {
			context.handleChange(key, value);
		  }
		}
	  };
	}
}