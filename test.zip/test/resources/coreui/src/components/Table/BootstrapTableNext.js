import React, {Component} from 'react';
import {Redirect, withRouter} from 'react-router-dom';
import { connect } from 'react-redux';
import { bindActionCreators } from 'redux';
import {Translate, Localize} from 'react-redux-i18n'

import * as usersActions from '@/actions/usersActions';

import 'react-bootstrap-table-next/dist/react-bootstrap-table2.min.css';
import 'react-bootstrap-table2-filter/dist/react-bootstrap-table2-filter.min.css';
import 'react-bootstrap-table2-paginator/dist/react-bootstrap-table2-paginator.min.css';

import BootstrapTable from 'react-bootstrap-table-next';
import paginationFactory from 'react-bootstrap-table2-paginator';
import filterFactory, { textFilter } from 'react-bootstrap-table2-filter';
import { setLocale} from 'react-redux-i18n'
class BootstrapTableNext extends Component {
    /**
     * Document của thư viện:
     * https://react-bootstrap-table.github.io/react-bootstrap-table2/docs/table-props.html
     *  Các props bắt buộc:
     * keyField = '_id' //key chính của table
     * data = { data } //dữ liệu
     * page = { page } //số trang hiện tại
     * sizePerPage = { perPage } //số item/trang
     * totalSize = { total } //tổng số item
     * columns={ columns } //config cột
     * pagination ={ paginationOption } option phân trang:  https://react-bootstrap-table.github.io/react-bootstrap-table2/docs/table-props.html
     * onTableChange = { (type, newState) => (this.onTableChange(type, newState))}
     */
    constructor(props) {
            super(props);
    }
    async componentDidMount(){

    }
    componentDidUpdate(prevProps){

    }

    getPaginationOption(){
        let page = this.props.page || 1
        let sizePerPage = this.props.sizePerPage || 10
        let totalSize = this.props.totalSize || 1
        return paginationFactory({
            page, // Specify the current page. It's necessary when remote is enabled
            sizePerPage, // Specify the size per page. It's necessary when remote is enabled
            totalSize, // Total data size. It's necessary when remote is enabled
            pageStartIndex: 1, // first page will be 0, default is 1
            paginationSize: 5,  // the pagination bar size, default is 5
            sizePerPageList: [ {
              text: '5', value: 5
            }, {
              text: '10', value: 10
            }], // A numeric array is also available: [5, 10]. the purpose of above example is custom the text
            withFirstAndLast: false, // hide the going to first and last page button
            alwaysShowAllBtns: true, // always show the next and previous page button
            firstPageText: 'First', // the text of first page button
            prePageText: 'Prev', // the text of previous page button
            nextPageText: 'Next', // the text of next page button
            lastPageText: 'Last', // the text of last page button
            nextPageTitle: 'Go to next', // the title of next page button
            prePageTitle: 'Go to previous', // the title of previous page button
            firstPageTitle: 'Go to first', // the title of first page button
            lastPageTitle: 'Go to last', // the title of last page button
            hideSizePerPage: false, // hide the size per page dropdown
            hidePageListOnlyOnePage: true, // hide pagination bar when only one page, default is false
            onPageChange: (page, sizePerPage) => {}, // callback function when page was changing
            onSizePerPageChange: (sizePerPage, page) => {}, // callback function when page size was changing
            ...this.props.paginationOption
        })
    }
    getFilterOption(){
        return filterFactory({
            ...this.props.filterOption
        })
    }
    getRemoteOption(){
        return {
            filter: true,
            pagination: true,
            filter: true,
            sort: true,
            cellEdit: true
        }
    }
    onTableChange(type, newState){
        if(this.props.onTableChange){
            let params = Object.assign({}, newState)
            delete newState['data']  //xóa dữ liệu table trước khi gửi lên server
            this.props.onTableChange(type, newState)
        }
        else{
            console.log(type, newState)
            console.warn("gán props onTableChange(type, newState) cho table!");
        }
    }

    render() {
        const {users, data, keyField, columns} = this.props
        let paginationOption = this.getPaginationOption();
        let filterOption = this.getFilterOption();
        let remoteOption = this.getRemoteOption();
        return (
            <BootstrapTable
                keyField = {keyField}
                data ={ data }
                columns ={ columns }
                pagination ={ paginationOption }
                filter ={ filterOption }
                remote = { remoteOption }
                onTableChange = {(type, newState)=> (this.onTableChange(type, newState)) }
            />
        );
    }
}

const mapStateToProps = state => {
    return {

    }
}

const mapDispatchToProps = (dispatch, props) => {
    return {

    }
}
export default withRouter(connect(mapStateToProps, mapDispatchToProps)(BootstrapTableNext));
