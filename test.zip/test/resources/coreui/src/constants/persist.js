import storage from 'redux-persist/lib/storage'
export const persistConfig = {
	key: 'root',
	storage,
	whitelist: ['navigation'] //danh sách những store được phép lưu lại khi reload trang
}