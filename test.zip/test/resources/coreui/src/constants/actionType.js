//TABLE NEXT
export const TABLE_FETCH 	= 'TABLE_FETCH';

//USER
export const LOGIN 			= 'LOGIN';
export const USER_FETCH 	= 'USER_FETCH';
export const USER_FETCH_ALL = 'USER_FETCH_ALL';
export const USER_ADD 		= 'USER_ADD';
export const USER_EDIT 		= 'USER_EDIT';
export const USER_DELETE 	= 'USER_DELETE';
