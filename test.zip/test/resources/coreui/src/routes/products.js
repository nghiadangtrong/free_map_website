import React from 'react';

import Dashboard from '@/views/Dashboard/';
import Tables from '@/views/Base/Tables/';
import Modals from '@/views/Notifications/Modals/';
import Badges from '@/views/Notifications/Badges/';
export default [
	{
		path: "/products",
		name: "Products",
		component: () => <Tables />,
		exact: true,
	},
	{
		path: "/products/add",
		name: "Add",
		component: () => <Badges />,
		exact: false
	},
	{
		path: "/products/:id/edit",
		name: "Tables",
		component: () => <Modals />,
		exact: false
	}
	
]