import React from 'react';

import Dashboard from '@/views/Dashboard/';
import products from './products'
import users from './users'
export default [
	{
		path: "/dashboard",
		name: "Dashboard",
		component: () => <Dashboard />,
		exact: false
	},
	...products,
	...users
]