import React from 'react';
import List from '@/views/Users/Index';
import Create from '@/views/Users/Create';
import Edit from '@/views/Users/Edit';
import {Translate, Localize} from 'react-redux-i18n'
export default [
	{
		path: "/users",
		name: <Translate value="users.breadcrumbs.index" />, //bắt buộc dùng thẻ Translate, không được dùng I18n
		component: () => <List />,
		exact: true,
	},
	{
		path: "/users/add",
		name: <Translate value="users.breadcrumbs.add" />,
		component: () => <Create />,
		exact: false
	},
	{
		path: "/users/:id/edit",
		name: <Translate value="users.breadcrumbs.edit" />,
		component: () => <Edit />,
		exact: false
	}
	
]