import * as types from '@/constants/actionType'
var initialState = [];

const users = (state = initialState, action) => {
	switch (action.type) {
        case types.LOGIN:
			if(action.success){
				return action
			}
			return [...state];
			break;
		case types.USER_FETCH:
			if(action.data !== undefined){
				return action
			}
			else{
				//xử lý lỗi
				console.log("error")
			}
			return [...state];
			break;
        case types.USER_FETCH_ALL:
			if(action.data !== undefined){
				return action
			}
			else{
				//xử lý lỗi
				console.log("error")
			}
			return [...state];
            break;


		default: return [...state];
	}
};

export default users;
