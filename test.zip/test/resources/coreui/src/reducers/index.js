import { combineReducers } from 'redux';
import { reducer as formReducer } from 'redux-form'
import { i18nReducer } from 'react-redux-i18n';
import { persistReducer } from 'redux-persist'
import {persistConfig} from '@/constants/persist'
import users from './users';

const rootReducer = combineReducers({
	form: formReducer,
    users,
	i18n: i18nReducer
});

const persistedReducer = persistReducer(persistConfig, rootReducer)
export default persistedReducer;
