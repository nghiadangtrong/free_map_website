var webpack = require('webpack');
var path = require('path');
var dotenv = require('dotenv').config()

var BUILD_DIR = path.resolve(__dirname, 'public');
var APP_DIR = path.resolve(__dirname, 'resources/coreui/src');

module.exports = (env = {}) => {
	 return {
		  entry: [
			  'babel-polyfill', 
			  APP_DIR + '/index.js'
			],
		  output: {
		    path: BUILD_DIR,
		    filename: 'bundle.js'
		  },
		  devtool: (dotenv.parsed.NODE_ENV === "production" ? 'source-map' : 'cheap-module-eval-source-map'),
		  mode: dotenv.parsed.NODE_ENV,
		  performance: {
			hints: dotenv.parsed.NODE_ENV === 'production' ? "warning" : false
		  },
		  devServer: {
			contentBase: path.join(__dirname, "public"),
			hot: dotenv.parsed.DEV_HOT_ENABLE == "true" ? true: false,
			port: dotenv.parsed.DEV_PORT,
			allowedHosts: dotenv.parsed.DEV_ALLOW_HOSTS.split(","),
			proxy: {
				"/": {
					target: dotenv.parsed.HTTP_METHOD + "://" + dotenv.parsed.HOST + ":" + dotenv.parsed.PORT,
					secure: false
				}
			}
		  },
		  module : {
		    rules : [
		      {
		        test: /\.(js|jsx)$/,
		        include : APP_DIR,
		        loader : ['babel-loader']
		      },
		      {
		        test: /\.html$/,
		        loader: 'html-loader'
		      },
		      {
		        test: /\.(css)$/,
		        loaders: [
		          'style-loader',
		          'css-loader'
		        ],
		      },
		      {
		        test: /\.(scss)$/,
		        use: [
		            {
		              loader: 'style-loader'
		            },
		            {
		              loader: 'css-loader',
		              options: {alias: {'../img': '../public/img'}}
		            },
		            {
		                loader: 'sass-loader'
		            }
		        ]
		      },
		      {
		        test: /\.(png|jpg|jpeg|gif|ico)$/,
		        use: [
		          {
		            loader: 'file-loader',
		            options: {
		              name: './img/[name].[hash].[ext]'
		            }
		          }
		        ]
		      },
		      {
		        test: /\.(woff(2)?|ttf|eot|svg)(\?)?(\#iefix\&)?(v=\d+\.\d+\.\d+)?$/,
		        loader: 'file-loader',
		        options: {
		            name: './fonts/[name].[hash].[ext]'
		         }
		      }
		    ]
		  },
		  plugins: [
			new webpack.DefinePlugin({
				'process.env.LANG_DEFAULT': JSON.stringify(dotenv.parsed.LANG_DEFAULT),
				'process.env.HTTP_METHOD': JSON.stringify(dotenv.parsed.HTTP_METHOD),
				'process.env.HOST': JSON.stringify(dotenv.parsed.HOST),
				'process.env.PORT': JSON.stringify(dotenv.parsed.PORT)
			}),
		  ],
		  resolve:{
			alias:{
				'@': path.join(__dirname, '/resources/coreui/src/')
			}
		  }
	}
};