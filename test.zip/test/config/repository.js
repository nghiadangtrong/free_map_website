
module.exports = {
	pagination: {
		per_page: 100,
		page: 1
	},
	cache: false
}
