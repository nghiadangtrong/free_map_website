'use strict'

/*
|--------------------------------------------------------------------------
| Routes
|--------------------------------------------------------------------------
|
| Http routes are entry points to your web application. You can create
| routes for different URL's and bind Controller actions to them.
|
| A complete guide on routing is available here.
| http://adonisjs.com/docs/4.0/routing
|
*/

const Route = use('Route')

// RESTful API
// 
Route.group(() => {
	Route.post('/logout', 'Api/LoginController.logout')
	Route.resource('/users', 'Api/UserController').apiOnly()
	Route.resource('materials', 'Api/MaterialController').apiOnly()
	Route.resource('/products', 'Api/ProductController').apiOnly()
	Route.resource('/allergies', 'Api/AllergyController').apiOnly()
	Route.resource('/logs', 'Api/LogController').apiOnly()
}).prefix('api').middleware('auth')
Route.post('/lang', 'Api/LanguageController.trans')
Route.post('api/login', 'Api/LoginController.login')

//client routing
Route.any('*', ({ view }) => view.render('coreui'))
