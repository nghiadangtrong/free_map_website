const Q = require('q')
const path = require('path')
require('dotenv').config()

module.exports =class mongod {
	static run() {
		const host = process.env.DB_HOST || 'localhost'
		const port = process.env.DB_PORT || '27018'
		const pathDB = path.resolve(process.cwd(), process.env.BUILDIN_PATH  || './database')
		console.log(pathDB)
		let deferred = Q.defer();
		let { MongodHelper } = require('mongodb-prebuilt');
		let mongodHelper = new MongodHelper([
			'--port', port,
			'--bind_ip', host,
			'--dbpath', pathDB
		]);
		mongodHelper.run().then((started) => {
			console.log('mongod is running on: ' + host + ":" + port);
			deferred.resolve();
		}, (e) => {
			deferred.reject(e);
			console.log('error starting', e);
		});
		return deferred.promise;
	}
}