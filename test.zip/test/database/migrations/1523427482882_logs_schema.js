'use strict'

const Schema = use('Schema')

class LogsSchema extends Schema {
  up () {
    this.create('logs', (collection) => {
      // alter table
    })
  }

  down () {
    this.drop('logs')
  }
}

module.exports = LogsSchema
