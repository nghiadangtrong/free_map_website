'use strict'

const Schema = use('Schema')

class AllergiesSchema extends Schema {
  up () {
    this.create('allergies', (collection) => {
      // alter table
      collection.index('allergy_code_index', {code: 1}, {unique: true})
    })
  }

  down () {
    this.collection('allergies', (collection) => {
      // reverse alternations
      collection.dropIndex('allergy_code_index')
    })
    this.drop('allergies')
  }
}

module.exports = AllergiesSchema
