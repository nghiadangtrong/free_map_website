'use strict'

const Schema = use('Schema')

class UsersSchema extends Schema {
  up () {
    this.create('users', (collection) => {
      // alter table
      collection.index('user_code_index', {code: 1}, {unique: true});
    })
  }

  down () {
    this.collection('users', (collection) => {
      collection.dropIndex('user_code_index')
    });
    this.drop('users');
  }
}

module.exports = UsersSchema
