'use strict'

const Schema = use('Schema')

class MaterialsSchema extends Schema {
  up () {
    this.create('materials', (collection) => {
      collection.index('material_code_index', {code: 1}, {unique: true})
    })
  }

  down () {
    this.collection('materials', (collection) => {
      // reverse alternations
      collection.dropIndex('material_code_index')
    })
    this.drop('materials');
  }
}

module.exports = MaterialsSchema
