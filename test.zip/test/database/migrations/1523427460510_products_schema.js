'use strict'

const Schema = use('Schema')

class ProductsSchema extends Schema {
  up () {
    this.create('products', (collection) => {
      // alter table
      collection.index('product_code_index', {code: 1}, {unique: true})
    })
  }

  down () {
    this.collection('products', (collection) => {
      // reverse alternations
      collection.dropIndex('product_code_index');
    })
    this.drop('products');
  }
}

module.exports = ProductsSchema
