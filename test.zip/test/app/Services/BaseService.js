'use strict'

class BaseService {

}

module.exports = BaseService