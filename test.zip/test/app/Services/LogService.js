'use strict'
/**
 * The service to handle some bussiness action about manage materials.
 */
const BaseService = use('App/Services/BaseService')
cosnt LogRepository = use('App/Repositories/MongoRepositories/LogRepository')

class LogService extends BaseService {
	constructor() {
		this.logRepository = new LogRepository()
	}
}

module.exports = LogService