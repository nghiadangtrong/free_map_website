'use strict'
/**
 * The service to handle some bussiness action about manage products.
 */
const BaseService = use('App/Services/BaseService')
const ProductRepository = use('App/Repositories/MongoRepositories/ProductRepository')
const MaterialRepository = use('App/Repositories/MongoRepositories/MaterialRepository')

class ProductService extends BaseService {

	constructor() {
		this.productRepository = new ProductRepository()
		this.materialRepository = new MaterialRepository()
	}
}

module.exports = ProductService