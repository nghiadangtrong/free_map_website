'use strict'
/**
 * The service to handle some bussiness action about manage users.
 */
const BaseService = use('App/Services/BaseService')

class UserService extends BaseService {

}

module.exports = UserService