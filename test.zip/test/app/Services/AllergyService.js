'use strict'
/**
 * The service to handle some bussiness action about manage materials.
 */
const BaseService = use('App/Services/BaseService')
const AllergyRepository = use('App/Repositories/MongoRepositories/AllergyRepository')

class AllergyService extends BaseService {

	constructor () {
		this.allergyRepository = new AllergyRepository();
	}
}

module.exports = AllergyService