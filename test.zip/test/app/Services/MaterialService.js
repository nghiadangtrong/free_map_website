'use strict'
/**
 * The service to handle some bussiness action about manage materials.
 */
const BaseService = use('App/Services/BaseService')

class MaterialService extends BaseService {

}

module.exports = MaterialService