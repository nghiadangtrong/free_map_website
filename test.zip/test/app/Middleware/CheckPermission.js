'use strict'
const Config = use('Config')
const AccessDeniedException = use('App/Exceptions/AccessDeniedException')

class CheckPermission {
  async handle ({ request, auth }, next, params) {
  	if(params) {
	  	let userAction = await this.getUserAction(request.method())
	  	let feature = params[0];
	  	let urlExtendRes = false; // the route extend from resource route.
	  	if(params.length > 1) {
	  		if(params[1] == 'true') {
	  			urlExtendRes = true;
	  		} else {
	  			urlExtendRes = false;
	  		}
	  	}
		// let hasPermission = false;
	  	const  hasPermission = await this.checkPermission(auth, feature, userAction, urlExtendRes)
		if(hasPermission) {
	    	await next()
		} else {
			throw AccessDeniedException.invoke()
		}
  		
  	}

    // call next to advance the request
  }

  async checkPermission(auth, feature, userAction, urlExtendRes) {
  	const permissions = await Config.get('permission.permission_features')
  	let hasPermission = false;
	for(let role of auth.user.roles) {
		if(permissions[feature][role] >= userAction) {
			hasPermission = true;
			break;
		}
	}
	
	return hasPermission
  }

  async getUserAction(method) {
  	const actions = await Config.get('permission.actions')
  	let userAction = null;
  	if(method == 'HEAD' || method == 'GET') {
		userAction = actions.view;
	} else if(method == 'POST') {
		userAction = actions.create;
	} else if(method == 'PUT' || method == 'PATCH') {
		userAction = actions.update
	} else if(method == 'DELETE') {
		userAction = actions.delete
	}

	return userAction;
  }


}

module.exports = CheckPermission
