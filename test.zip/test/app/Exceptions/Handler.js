'use strict'

const BaseExceptionHandler = use('BaseExceptionHandler')

/**
 * This class handles all exceptions thrown during
 * the HTTP request lifecycle.
 *
 * @class ExceptionHandler
 */
class ExceptionHandler extends BaseExceptionHandler {
    /**
     * Handle exception thrown during the HTTP lifecycle
     *
     * @method handle
     *
     * @param  {Object} error
     * @param  {Object} options.request
     * @param  {Object} options.response
     *
     * @return {void}
     */
    async handle (error, { request, response }) {
        if (request.url().indexOf('/api/') >= 0) {
            let json = {
                message: error.message,
                errors: error.errors
            }
            if (use('Env').get('NODE_ENV') === 'development') {
                json.traces = error.stack
            }
            return response.status(error.status).json(json)
        }

        if (error.code === 'E_INVALID_SESSION') {
            session.flash({ error: 'You must be authenticated to access this page!' })

            return response.redirect('/login')
        }

        return super.handle(...arguments)
    }

    /**
     * Report exception for logging or debugging.
     *
     * @method report
     *
     * @param  {Object} error
     * @param  {Object} options.request
     *
     * @return {void}
     */
    async report (error, { request }) {
        error.status === 500 && console.log(error)
    }
}

module.exports = ExceptionHandler
