'use strict'
const Config = use('Config')
class UserPolicy {
	/**
	 * [add a new user]
	 * @param {App/Models/User instance} userAction [the user want to create new account.]
	 * @param {App/Models/User class} user       [The model class will be created]
	 */
	static async add(userAction, user) {
		let RootRole = await Config.get('permission.roles.root');
		let AdminRole = await Config.get('permission.roles.admin');
		if(userAction.roles.includes(RootRole) 
			|| userAction.roles.includes(AdminRole)) { // have root role or admin role
			return true;
		} else {
			return false;
		}
	}
	/**
	 * [edit an existed user]
	 * @param  {App/Models/User} userAction [the user instance want to update an other account]
	 * @param  {App/Models/User} user       [The user instance will be updated by userAction if userAction can be allowed]
	 * @return {boolean}            [the result allow / not allow to update user instance]
	 */
	static async edit(userAction, user) {
		let RootRole = await Config.get('permission.roles.root');
		let AdminRole = await Config.get('permission.roles.admin');
		let EmployeeRole = await Config.get('permission.roles.employee');
		if(userAction.roles.includes(RootRole) 
			|| (userAction.roles.includes(AdminRole) && user.roles.includes(EmployeeRole) && !user.roles.includes(RootRole)) 
			|| (userAction._id === user._id && userAction.roles.includes(EmployeeRole)) { // have root role or admin role
			return true
		} else {
			return false
		}
	}
	/**
	 * [delete an existed App/Models/User instance]
	 * @param  {App/Models/User} userAction [UserAction will delete the user instance]
	 * @param  {App/Models/User} user       [The user instance will be deleted.]
	 * @return {boolean}            [Allow/Not allow to delete the user instance]
	 */
	static delete(userAction, user) {
		let RootRole = Config.get('permission.roles.root');
		let AdminRole = Config.get('permission.roles.admin');
		let employeeRole = Config.get('permission.roles.employee')
		if(userAction.roles.includes(RootRole) && userAction._id !== user._id && user.code != 'root') { // have root role or admin role
			return true
		} else if(userAction.roles.includes(AdminRole) && user.roles.includes(employeeRole) 
			&& userAction._id !== user._id && user.code != 'root') {
			return false
		}
	}
}

module.exports = UserPolicy