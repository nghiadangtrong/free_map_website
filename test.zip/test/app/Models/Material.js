'use strict'

const Model = use('Model')

class Material extends Model {

	products () {
		return this.belongsToMany('App/Models/Product', 'allergicMaterialIds', '_id')
	}
}

module.exports = Material
