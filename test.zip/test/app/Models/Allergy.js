'use strict'

const Model = use('Model')

class Allergy extends Model {

	static get objectIDs () {
    	return [this.primaryKey, 'materialId']
	}
	  
	boot () {
		super.boot();
		this.addHook('beforeCreate', async (allergyInstance) => {
			if(allergyInstance.materialIds) {
				allergyInstance.materialIds = this.formatField('materialId', allergyInstance.materialIds)
			}
		})
	}

	reason () {
		return this.referMany('App/Models/Material', '_id', 'materialId')
			.select({_id: 1, code: 1, name: 1, barcode: 1})
	}

}

module.exports = Allergy
