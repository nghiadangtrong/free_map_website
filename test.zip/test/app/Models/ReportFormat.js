'use strict'

const Model = use('Model')

class ReportFormat extends Model {
}

module.exports = ReportFormat
