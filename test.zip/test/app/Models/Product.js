'use strict'

const Model = use('Model')

class Product extends Model {

	static get objectIDs () {
    	return [this.primaryKey, 'materialId'];
	  }

	static boot () {
		super.boot()
		this.addHook('beforeCreate', async (productInstance) => {
	      	if (productInstance.materialIds) {
	        	productInstance.materialIds = this.formatField('materialId', productInstance.materialIds)
	      	}
	    })
	}

	materials () {
		return this.referMany('App/Models/Material', '_id', 'materialId')
			.select({code: 1, name: 1, barcode: 1})
	}
	
}

module.exports = Product
