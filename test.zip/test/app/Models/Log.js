'use strict'

const Model = use('Model')

class Log extends Model {
	user () {
		return this.embedOne('App/Models/User', '_id', 'user')
	}

	product () {
		return this.embedOne('App/Models/Product', '_id', 'product')
	}

	used_materials () {
		return this.embedOne('App/Models/Materials', '_id', 'used_materials')
	}

}

module.exports = Log
