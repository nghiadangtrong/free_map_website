'use strict'
const Repository = use('App/Repositories/MongoRepositories/MaterialRepository')
const ApiController = use('App/Controllers/Http/Api/ApiController')
const InvalidArgumentException = use('App/Exceptions/InvalidArgumentException')
const Moment = use('moment');
class MaterialController extends ApiController {

  constructor() {
    super(Repository);
  }

  async index ({request, response}) {
    let paginateParams = request.getPaginateParams();
    let keyword = request.input('key_search');
    const materials = await this.repository.searchAll(keyword).orderBy({created_at: 'desc'})
      .paginate(paginateParams.page, paginateParams.limit)
    
    return response.apiSuccess(materials);
  }

  // async create () {
  // }

  async store ({request, response}) {
    let inputs = request.only(['code', 'name', 'barcode'])
    if(inputs) {
      if(!inputs.code) {
        let patterns = ['M', 'MA', 'MT', 'MAT', 'MTR'];
        let maxCodeLength = 8;
        let availableCode = null
        for(let i = 0; i < patterns.length; i++) {
          availableCode = await this.genMaterialCode(patterns[i], maxCodeLength)
          if(availableCode) {
            break;
          }
        }
        if(availableCode) {
          inputs['code'] = availableCode
        } else {
          return response.apiNoContent()
        }
      }
      if(!inputs.barcode) {
        let barcode = await this.genBarcodeEan13()
        inputs['barcode'] = barcode;
      } else if(inputs.barcode.length == 12) {
        inputs.barcode += this.getCheckNumberEAN(inputs.barcode)
      }
      
      const rs = await this.repository.create(inputs)
      if(rs) {
        return response.apiCreated(rs)
      } else {
        return response.apiNoContent()
      }
    }
  }

  async show ({params, request, response}) {
    let id = params.id;
    if(!id) {
      throw InvalidArgumentException.invoke('Not found :id argument on router.')
    }
    const material = await this.repository.find(id);
    if(material) {
      return response.apiSuccess(material);
    } else {
      return response.apiNoContent();
    }
  }

  // async edit () {
  // }

  async update ({params, request, response}) {
    let id = params.id;
    if(!id) {
      throw InvalidArgumentException.invoke('Not found :id argument on router.')
    }
    let inputs = request.only(['code', 'name', 'barcode'])
    let material = await this.repository.find(id)
    if(material) {
        if(!inputs.code) {
          inputs['code'] = material.code
        }
        if(!inputs.barcode) {
          inputs['barcode'] = material.barcode
        }
        
        const rs = await this.repository.update(id, inputs)
        if(rs) {
          return response.apiSuccess(rs)
        } else {
          return response.apiNoContent()
        }
    } else {
      return response.apiNoContent()
    }
  }

  async destroy ({params, request, response}) {
    let id = params.id;
    if(!id) {
      throw InvalidArgumentException.invoke('Not found :id argument on router.')
    }
    const rs = await this.repository.delete(id)
    if(rs) {
      return response.apiSuccess()
    } else {
      return response.apiNoContent()
    }
  } 

  async generateBarcode ({request, response}) {

  }
  
  getCheckNumberEAN(barcode, length = 13) {
    let size = barcode.length;
    if(size < length && size == 12) {
      let sumEvenIndexs = 0;
      let sumOddIndexs = 0;
      for(let i = 0; i < size; i++) {
        if(i % 2 == 0) {
          sumOddIndexs += parseInt(barcode.charAt(i))
        } else {
          sumEvenIndexs += parseInt(barcode.charAt(i))
        }
      }
      let sumIndexs = sumEvenIndexs * 3 + sumOddIndexs
      let n = sumIndexs % 10;

      return n == 0 ? 0 : 10 - n;
    } else {
      return null;
    }
  }

  async genBarcodeEan13() {
    let barcodePattern = '29';
    let year = String(Moment().year()).substring(2, 4)
    let month = String(Moment().month() + 1).padStart(2, '0');
    barcodePattern += year + month;
    let barcodeReg = new RegExp(barcodePattern + '[0-9]+');
    let lastBarcode = await this.repository.select([{barcode: 1}]).whereLike({barcode: barcodeReg}).orderBy({barcode: 'desc'}).first()
    if(lastBarcode) {
      let lastBarcodeSubStr = lastBarcode.barcode.substring(barcodePattern.length, 12);
      let newBarcodeSubStr = parseInt(lastBarcodeSubStr) + 1;
      newBarcodeSubStr = String(newBarcodeSubStr).padStart(6, '0');
      let barcode = barcodePattern + newBarcodeSubStr;
      let checkNum = this.getCheckNumberEAN(barcode);

      return barcode + checkNum;
    } else {
      let newBarcodeSubStr = String(1).padStart(6, '0')
      let barcode = barcodePattern + newBarcodeSubStr;
      let checkNum = this.getCheckNumberEAN(barcode)
      console.log(barcode + checkNum);
      return barcode + checkNum;
    }
  }

  async genMaterialCode (pattern = 'M', length = 8) {
    const maxSubCode = Math.pow(10, length - 1) - 1;
    let codeRegx =  new RegExp(pattern + '[0-9]{' + (length - 1) + '}');
    let lastCode = await this.repository.whereLike({code: codeRegx}).orderBy({code: 'desc'}).first()
    if(lastCode) {
      let lastCodeSubStr = lastCode.code.substring(pattern.length, length + 1)
      let newCodeSubStr = parseInt(lastCodeSubStr) + 1;
      console.log(maxSubCode)
      if(newCodeSubStr > maxSubCode) {
        newCodeSubStr = null;
        console.log('search available code')
        newCodeSubStr = await this.searchAvailableCode(pattern, length)
        if(newCodeSubStr) {
          return pattern + String(newCodeSubStr).padStart(length - pattern.length, '0')
        } else {
          return null
        }
      } else {
        return pattern + String(newCodeSubStr).padStart(length - pattern.length, '0')
      }
    } else {
      let newCodeSubStr = String(1).padStart(length - 1, '0')

      return pattern + newCodeSubStr
    }
  }

  async searchAvailableCode(pattern, length) {
    const maxSubCode = Math.pow(10, length - pattern.length) - 1;
    let codeRegx = new RegExp(pattern + '[0-9]{' + (length - 1) + '}')

    let docs = await this.repository.whereLike({code: codeRegx}).select([{code: 1}]).orderBy({code: 'asc'}).all()
    docs = docs.rows;
    let codes = [];
    let availableCode = null;
    for(let i =  0; i < docs.length; i++) {
      codes.push(parseInt(docs[i].code.substring(pattern.length, length + 1)));
    }
    for(let c = 1; c < maxSubCode; c++) {
      if(!codes.includes(c)) {
        availableCode = c;
        break;
      }
    }

    return availableCode;
  }
}

module.exports = MaterialController
