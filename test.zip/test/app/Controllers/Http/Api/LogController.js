'use strict'

const ApiController = use('App/Controllers/Http/Api/ApiController')
const Repository = use('App/Repositories/MongoRepositories/LogRepository')
const InvalidArgumentException = use('App/Exceptions/InvalidArgumentException')
const Moment = use('moment')

class LogController extends ApiController {
  constructor () {
    super(Repository)
  }
  async index ({ request, response}) {
    let paginateParams = request.getPaginateParams();
    let {user_id, begin, end, status} = request.only(['limit', 'page', 'user_id', 'begin', 'end'])
    let conditions = {};
    if(user_id) {
      conditions['user._id'] = user_id;
    }
    if(begin) {
      begin = Moment.utc(begin)
      if(!conditions.created_at) {
        conditions['created_at'] = {$gte: begin};
      }
    }

    if(end) {
      end = Moment.utc(end).add(1, 'd').toDate();
      if(!conditions.created_at) {
        conditions['created_at'] = {$lt: end};
      } else {
        conditions.created_at['$lt'] = end; 
      }
    }
    let totalLogs = await this.repository.where(conditions).all()
    if(status) {
      if(status.toLowerCase == 'false' || status == 0 || status == '0') {
        conditions['status'] = false;
      } else {
        conditions['status'] = true;
      }
    } else {
      conditions['status'] = false;
    }
    let logs = await this.repository.where(conditions).orderBy({created_at: 'desc'}).paginate(paginateParams.page, paginateParams.limit)

    logs.totalTimes = totalLogs.length;
    if(conditions['status'] == false) {
      logs.trueTimes = totalLogs.length - logs.total;
      logs.falseTimes = logs.total;
      logs.truePercent = (totalLogs.length - logs.total) / totalLogs.length * 100;
      logs.falsePercent = logs.total / totalLogs.length * 100;
    } else {
      logs.falseTimes = totalLogs.length - logs.total
      logs.trueTimes = logs.total;
      logs.falsePercent = (totalLogs.length - logs.total) / totalLogs.length * 100;
      logs.truePercent = logs.total / totalLogs.length * 100;
    }
    
    return response.apiSuccess(logs)
  }

  // async create () {
  // }

  // async store () {c
  async show ({params, request, response}) {
    let id = params.id;
    if(!id) {
      throw InvalidArgumentException.invoke('Not found :id argument on router.')
    }
    const log = await this.repository.find(id)
    if(log) {
      return response.apiSuccess(log)
    } else {
      return response.apiNoContent()
    }
  }

  // async edit () {
  // }

  // async update () {
  // }

  // async destroy () {
  // }

}

module.exports = LogController
