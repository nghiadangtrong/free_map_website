'use strict'

const Repository = use('App/Repositories/MongoRepositories/ProductRepository')
const ApiController = use('App/Controllers/Http/Api/ApiController')
const InvalidArgumentException = use('App/Exceptions/InvalidArgumentException')
const LogRepository = use('App/Repositories/MongoRepositories/LogRepository')
const MaterialRepository = use('App/Repositories/MongoRepositories/MaterialRepository')
const AllergyRepository = use('App/Repositories/MongoRepositories/AllergyRepository')

class ProductController extends ApiController {

  constructor () {
    super(Repository)
    this.allergyRepository = new AllergyRepository()
    this.logRepository = new LogRepository()
    this.materialRepository = new MaterialRepository()
  }

  async index ({request, response}) {
    let paginateParams = request.getPaginateParams()
    let keyword = request.input('key_search')
    const products = await this.repository.with(['materials']).searchAll(keyword).orderBy({created_at: 'desc'})
      .paginate(paginateParams.page, paginateParams.limit)

    return response.apiSuccess(products)
  }

  // async create () {
  // }

  async store ({request, response}) {
    let inputs = request.only(['code', 'name', 'materialIds']);
    if(inputs) {
      if(!inputs.code) {
        let maxCodeLength = 8;
        let patterns = ['P', 'PR', 'PRD', 'PRO', 'PRT', 'PRDT'];
        let availableCode = null;
        for(let i = 0; i < patterns.length; i++) {
          availableCode = await this.genProductCode(patterns[i], maxCodeLength)
          if(availableCode) {
            break;
          }
        }
        if(availableCode) {
          inputs['code'] = availableCode
        } else {
          return response.apiNoContent()
        }
      } 
      const rs = await this.repository.create(inputs)

      if(rs) {
        return response.apiCreated(rs)
      } else {
        return response.apiNoContent()
      }
    } else {
      return response.apiNoContent()
    }
  }

  async show ({params, request, response}) {
    let id = params.id;
    if(!id) {
      throw IvalidArgumentException.invoke('Not found :id argument on router.')
    }

    let product = await this.repository.with(['materials']).find(id)
    if(product) {
      return response.apiSuccess(product)
    }else {
      return response.apiNoContent()
    }
  }

  // async edit () {
  // }

  async update ({params, request, response}) {
    let id = params.id;
    if(!id) {
      throw IvalidArgumentException.invoke('Not found :id argument on router.')
    } else {
      let inputs = request.only(['code', 'name', 'materialIds'])
      let product = await this.repository.find(id)
      if(product) {
        if(!inputs.code) {
          inputs['code'] = product.code
        }
        
        const rs = await this.repository.update(id, inputs)
        if(rs) {
          return response.apiSuccess(rs)
        } else {
          return response.apiNoContent()
        }
      } else {
        return response.apiNoContent()
      }
    }
  }

  async destroy ({params, request, response}) {
    let id = params.id;
    if(!id) {
      throw IvalidArgumentException.invoke('Not found :id argument on router.')
    }
    const rs = await this.repository.delete(id)
    if(rs) {
      return response.apiSuccess()
    } else{
      return response.apiNoContent()
    }
  }

  async getMaterialOfProductByBarcode ({params, request, response, auth}) {
    let productID = params.id
    let barcode = params.barcode
    let product = await this.repository.with(['materials']).find(productID)
    if(product) {
      let productMaterials = await product.materials().fetch()
      if(productMaterials.size() > 0) {
        productMaterials = productMaterials.rows
        let usedMaterial = await this.materialRepository.where({barcode: barcode}).first()
        if(usedMaterial) {
          let materialIDs = [];
          let logData = {
            user: {
              _id: auth.user._id,
              code: auth.user.code,
              name: auth.user.name
            },
            status: true,
            product: {
              _id: product._id,
              code: product.code,
              name: product.name,
              materials: []
            },
            usedMaterial: {
              _id: usedMaterial._id,
              code: usedMaterial.code,
              name: usedMaterial.name,
              barcode: usedMaterial.barcode
            },
            allergies: []
          }

          for(let prodMaterial of productMaterials) {
            materialIDs.push(prodMaterial._id.toString());
            logData.product.materials.push({_id: prodMaterial._id, code: prodMaterial.code, name: prodMaterial.name, barcode: prodMaterial.barcode})
          }
          let potentialAllergies = await this.allergyRepository.with(['reason']).where({
            materialIds: {
              $elemMatch: {
                  $in: materialIDs
              }
            }
          }).select(['code', 'name', '_id', 'materialIds']).all()

          let usedMaterialId = usedMaterial._id.toString()
          if(!materialIDs.includes(usedMaterialId)) {
            logData.status = false
            if(potentialAllergies && potentialAllergies.rows.length > 0) {
              potentialAllergies = potentialAllergies.rows
              for(let potential of potentialAllergies) {
                let isAllergy = false;
                for(let materialId of potential.materialIds) {
                  if(materialId.toString() == usedMaterialId) {
                    isAllergy = true;
                    break;
                  }
                }
                if(isAllergy) {
                  let reasons = await potential.reason().select('_id', 'code', 'name').fetch();
                  reasons = reasons.rows;
                  let allergy = {
                    _id: potential._id,
                    code: potential.code,
                    name: potential.name,
                    reason: []
                  }
                  for(let reason of reasons) {
                    allergy.reason.push({
                      _id: reason._id,
                      code: reason.code,
                      name: reason.name
                    })
                  }
                  logData.allergies.push(allergy);
                }
              }
            } 
          } 
          let log = await this.logRepository.create(logData)
          return response.apiSuccess(logData)
        } else {
          return response.apiNoContent('')
        }
      } else {
        return response.apiNoContent()
      }
    } else {
      return response.apiNoContent()
    }
  }

  async genProductCode(pattern = 'P', length = 8) {
    const maxSubCode = Math.pow(10, length - 1)
    let codeRegx = new RegExp(pattern + "[0-9]{" + (length - 1) + "}")
    let lastCode = await this.repository.whereLike({code: codeRegx}).orderBy({code: 'desc'}).first()
    if(lastCode) {
      let lastCodeSubStr = lastCode.code.substring(1, length)
      let newCodeSubStr = parseInt(lastCodeSubStr) + 1;
      if(newCodeSubStr > maxSubCode) {
        newCodeSubStr = null
        newCodeSubStr = await this.searchAvailableCode(pattern, length)
        if(newCodeSubStr) {
          return pattern + String(newCodeSubStr).padStart(length - pattern.length, '0')
        } else {
          return null
        }
      } else {
        return pattern + String(newCodeSubStr).padStart(length - 1, '0')
      }
    } else {
      let newSubCode = String(1).padStart(length - 1, '0')
      return pattern + newSubCode
    }
  }

  async searchAvailableCode(pattern, length) {
    const maxSubCode = Math.pow(10, length - pattern.length) - 1;
    let codeRegx = new RegExp(pattern + '[0-9]{' + (length - 1) + '}')

    let docs = await this.repository.whereLike({code: codeRegx}).select([{code: 1}]).orderBy({code: 'asc'}).all()
    docs = docs.rows;
    let codes = [];
    let availableCode = null;
    for(let i =  0; i < docs.length; i++) {
      codes.push(parseInt(docs[i].code.substring(pattern.length, length + 1)));
    }
    for(let c = 1; c < maxSubCode; c++) {
      if(!codes.includes(c)) {
        availableCode = c;
        break;
      }
    }

    return availableCode;
  }
}

module.exports = ProductController
