'use strict'
const Antl = use('Antl')

class ApiController {
	constructor(Repository) {
		this.repository = new Repository();
		this.trans = Antl;
	}
	
}

module.exports = ApiController