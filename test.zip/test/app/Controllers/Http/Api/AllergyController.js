'use strict'

const Repository = use('App/Repositories/MongoRepositories/AllergyRepository');
const ApiController = use('App/Controllers/Http/Api/ApiController')
const InvalidArgumentException = use('App/Exceptions/InvalidArgumentException')

class AllergyController extends ApiController {

  constructor () {
    super(Repository)
  }

  async index ({request, response}) {
    let paginateParams = request.getPaginateParams()
    let keyword = request.input('key_search')
    const allergies = await this.repository.with(['reason']).searchAll(keyword).orderBy({created_at: 'desc'})
    .paginate(paginateParams.page, paginateParams.limit)

    return response.apiSuccess(allergies)
  }

  // async create () {
  // }

  async store ({request, response}) {
    let inputs = request.only(['code', 'name', 'materialIds']);
    if(inputs) {
      if(!inputs.code) {
        let maxCodeLength = 8;
        let patterns = ['A', 'AL', 'AG', "ALG", 'ALGY'];
        for(let i = 0; i < patterns.length; i++) {
          availableCode = await this.genAllergyCode(patterns[i], maxCodeLength)
          if(availableCode) {
            break;
          }
        }
        if(availableCode) {
          inputs['code'] = availableCode
        } else {
          return response.apiNoContent()
        }
      }
      const rs = await this.repository.create(inputs)
      if(rs) {
        return response.apiCreated(rs)
      } else {
        
      }
    }
  }

  async show ({params, request, response}) {
    let id = params.id;
    if(!id) {
      throw InvalidArgumentException.invoke('Not found :id argument on router')
    }
    const allergy = await this.repository.with(['reason']).find(id)
    if(allergy) {
      return response.apiSuccess(allergy)
    } else {
      return response.apiNoContent()
    }
  }

  // async edit () {
  // }

  async update ({params, request, response}) {
    let id = params.id;
    if(!id) {
      throw InvalidArgumentException.invoke('Not found :id argument on router')
    }
    let allergy = await this.repository.find(id)
    if(allergy) {
      if(!inputs.code) {
        inputs['code'] = allergy.code;
      }

      const rs = await this.repository.update(id, request.only(['code', 'name', 'materialIds']))
      if(rs) {
        return response.apiSuccess(rs)
      } else {
        return response.apiNoContent()
      }
    } else {
      return response.apiNoContent()
    }
  }

  async destroy ({params, request, response}) {
    let id = params.id;
    if(!id) {
      throw InvalidArgumentException.invoke('Not found :id argument on router')
    } else {
      const rs = await this.repository.delete(id)
      if(rs) {
        return response.apiSuccess(rs)
      } else {
        return response.apiNoContent()
      }
    }

  }
  async genAllergyCode(pattern = 'A', length = 8) {
    const maxSubCode = Math.pow(10, length - 1) - 1;
    let codeRegx =  new RegExp(pattern + '[0-9]{' + (length - 1) + '}');
    let lastCode = await this.repository.whereLike({code: codeRegx}).orderBy({code: 'desc'}).first()
    if(lastCode) {
      let lastCodeSubStr = lastCode.code.substring(pattern.length, length + 1)
      let newCodeSubStr = parseInt(lastCodeSubStr) + 1;
      console.log(maxSubCode)
      if(newCodeSubStr > maxSubCode) {
        newCodeSubStr = null;
        newCodeSubStr = await this.searchAvailableCode(pattern, length)
        if(newCodeSubStr) {
          return pattern + String(newCodeSubStr).padStart(length - pattern.length, '0')
        } else {
          return null
        }
      } else {
        return pattern + String(newCodeSubStr).padStart(length - pattern.length, '0')
      }
    } else {
      let newCodeSubStr = String(1).padStart(length - 1, '0')

      return pattern + newCodeSubStr
    }
  }

  async searchAvailableCode(pattern, length) {
    const maxSubCode = Math.pow(10, length - pattern.length) - 1;
    let codeRegx = new RegExp(pattern + '[0-9]{' + (length - 1) + '}')

    let docs = await this.repository.whereLike({code: codeRegx}).select([{code: 1}]).orderBy({code: 'asc'}).all()
    docs = docs.rows;
    let codes = [];
    let availableCode = null;
    for(let i =  0; i < docs.length; i++) {
      codes.push(parseInt(docs[i].code.substring(pattern.length, length + 1)));
    }
    for(let c = 1; c < maxSubCode; c++) {
      if(!codes.includes(c)) {
        availableCode = c;
        break;
      }
    }

    return availableCode;
  }
}

module.exports = AllergyController
