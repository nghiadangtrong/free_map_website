'use strict'

const ApiController = use('App/Controllers/Http/Api/ApiController')
const Repository = use('App/Repositories/MongoRepositories/ReportFormatRepository')

class ReportFormatController extends ApiController {

  constructor () {
    super(Repository)
  }

  async index ({request, response}) {
    let paginateParams = request.getPaginateParams()
    let keyword = request.input('key_search')
    const forms = await this.repository.searchAll(keyword).orderBy({created_at: 'desc'})
      .paginate(paginateParams.page, paginateParams.limit)

    return response.apiSuccess(forms)
  }

  // async create () {
  // }

  async store ({request, response}) {
    let inputs = request.all()
    if(inputs) {
      let rs = this.repository.create(inputs)
      if(rs) {
        return response.apiSuccess(rs)
      } else {
        return response.ApiNoContent()
      }
    }
  }

  async show ({params, request, response}) {
    let id = params.id;
    if(!id) {
      throw IvalidArgumentException.invoke('Not found :id argument on router.')
    }

    let form = await this.repository.find(id)
    if(form) {
      return response.apiSuccess(form)
    }else {
      return response.apiNoContent()
    }
  }

  // async edit () {
  // }

  async update ({params, request, response}) {
    let id = params.id
    if(!id) {
      throw IvalidArgumentException.invoke('Not found :id argument on router.')
    } else {
      let inputs = request.all()
      const rs = await this.repository.update(id, inputs)
      if(rs) {
        return response.apiSuccess(rs)
      } else {
        return response.apiNoContent()
      }
    }
  }


  async destroy ({params, request, response}) {
    let id = params.id
    if(!id) {
      throw IvalidArgumentException.invoke('Not found :id argument on router.')
    } else {
      let rs = this.repository.delete(id)
      if(rs) {
        return response.apiSuccess()
      } else {
        return response.apiNoContent()
      }
    }
  }
}

module.exports = ReportFormatController
