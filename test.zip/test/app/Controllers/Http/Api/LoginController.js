'use strict'

const ApiController = use('App/Controllers/Http/Api/ApiController')
const Repository = use('App/Repositories/MongoRepositories/UserRepository')
const ResourceNotFoundException = use('App/Exceptions/ResourceNotFoundException')
const BadRequestException = use('App/Exceptions/BadRequestException')
const UnauthorizedException = use('App/Exceptions/UnAuthorizedException')
const Trans = use('Antl')

class LoginController extends ApiController {
	constructor () {
		super(Repository);
	}

	async login ({auth, request, response}) {
		const {code, password} = request.only(['code', 'password']);
		const {user_barcode} = request.only(['user_barcode']);
		try {
			if(code && password) {
				const user = await this.repository.findBy('code', code);
				if(user) {
					const customPayload = await  this.makePayload(request, user, {roles: user.roles.toString()});
					let token = await auth.withRefreshToken().attempt(code, password, customPayload);
					token['user_id'] = user._id.toString();
					token['roles'] = user.roles;
					return response.apiSuccess(token);
				} else {
					throw ResourceNotFoundException.invoke(Trans.formatMessage('messages.auth_not_found_user_by_account', {code: code}))
				}
			} else if(user_barcode) {
				const user = await this.repository.findBy('user_barcode', user_barcode);
				if(user) {
					const customPayload = await  this.makePayload(request, user, {roles: user.roles.toString()});
					let token = await auth.withRefreshToken().generate(user, customPayload);
					token['user_id'] = user._id.toString();
					token['roles'] = user.roles;
					return response.apiSuccess(token)
				} else {
					throw ResourceNotFoundException.invoke(Trans.formatMessage('messages.auth_not_found_user_by_barcode', {barcode: user_barcode}))
				}
			} else {
				throw ResourceNotFoundException(Trans.get('messages.auth_not_enter_input_login'));
			}
		} catch (error) {
			throw UnauthorizedException.invoke(Trans.get('messages.cannot_login'))
		}
	}

	async logout ({request, response, auth}) {
		try {
			if(auth.check()) {
				await auth.logout();
				return response.apiSuccess();
			}
		} catch(e) {
			throw UnauthorizedException.invoke('Unauthorized')
		}
	}

	async refresh ({request, response, auth}) {
		let oldRefreshToken = reqyest.input('refresh_token')
		if(oldRefreshToken && oldRefreshToken.length > 0) {
			try {
				let authData = await auth.newRefreshToken()
					.generateForRefreshToken(oldRefreshToken)

				return response.apiSuccess(authData);
			} catch(e) {
				return response.apiServerError(e.message);
			}
		} else {
			throw UnauthorizedException.invoke('Cannot find old refresh token.')
		}
	}

	async makePayload(request, user, customClaims = {}) {
		let now = Math.floor(Date.now() / 1000);
	    let defaultClaims = {
	        issuer: this.iss(request), 
			iat: this.iat(now), 
	        // 'exp': exp(now, config.jwt_expired_in),
	        notBefore: this.nbf(now),
	        jti: await this.jti(),
	        subject: this.sub(user._id)
	    };
	    for(let claim in defaultClaims) {
	        if(!customClaims.hasOwnProperty(claim)) {
	            customClaims[claim] = defaultClaims[claim];
	        }
	    }

	    return customClaims;
	}

	iss(request) {
	    return request.url();
	}

	iat(now) {
	    return now;
	}

	exp(now, expiredIn) {
	    return parseInt(now + expiredIn * 60);
	}

	nbf(now) {
	    return now;
	}

	async jti(length = 16) {
		let text = "";
	    let possible = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789";
	    for(let i = 0; i < length; i++) {
	        text += possible.charAt(Math.floor(Math.random() * possible.length));
	    }
	    return text;
	}

	sub(subject) {
	    return subject;
	}
}

module.exports = LoginController
