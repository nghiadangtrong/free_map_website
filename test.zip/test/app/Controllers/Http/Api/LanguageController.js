'use strict'
const Antl = use('Antl')
class LanguageController {

	constructor () {
		
	}

	async trans({request, response}) {
		let keys = request.input('keys')
		let values = {};
		if(keys.length) {
			for (let key of keys) {
				let keySplits = key.split('.');
				if(keySplits.length > 2) {
					let group = await Antl.get(keySplits[0] + "." + keySplits[1])
					if(group) {
						for(let i = 2; i < keySplits.length; i++) {
							if(pair[keySplits[i]]) {
								group = group[keySplits[i]];
							} else {
								group = null;
								break;
							}
						}
					}
					values[key] = pair;
				} else {
					let value = await Antl.get(key);
					values[key] = value;
				}
			}
			return response.apiSuccess(values);
		}else {
			return response.apiError(values, 9000);
		}
	}
}

module.exports = LanguageController
