'use strict'

const ApiController = use('App/Controllers/Http/Api/ApiController');
const Repository = use('App/Repositories/MongoRepositories/UserRepository');
const InvalidArgumentException = use('App/Exceptions/InvalidArgumentException')
const Moment = use('moment')
class UserController extends ApiController {

  constructor () {
    super(Repository);
  }

  async index ({request, response}) {
    let {page, sizePerPage, filters} = request.getPaginateParams();
    try {
      let users = await this.repository.select(['_id','code','name','roles'])
      .getForTableNext(request.all()) //sử dụng hàm getForTableNext để có thể filter/sort/paginate tương thích với BootTrap Table Next trên client

      return response.apiSuccess(users);
    } catch(e) {
      throw e;
    }
  }

  // async create () {
  // }

  async store ({request, response, auth}) {
    let inputs = request.only(['code', 'name', 'password', 'roles'])
    if(inputs) {
      let canCreate = await auth.user.can('add', this.repository.makeModel())
      if(canCreate) {
        inputs['user_barcode'] = await this.genBarcodeEan13()
        const rs = await this.repository.create(inputs);
        if(rs) {
          return response.apiCreated(rs);
        } else {
          return reponse.apiNoContent()
        }
      } else {
        return response.apiNotModified(Trans.get('messages.cannot_add_user'))
      }
    }
  }

  async show ({params, request, response}) {
    let id = params.id;
    if(!id) {
      throw InvalidArgumentException.invoke('Not found :id argument on router.');
    }
    const user = await this.repository.find(id);
    if(user) {
      return response.apiSuccess(user);
    } else {
      return response.apiNoContent();
    }
  }

  // async edit () {
  // }

  async update ({params, request, response, auth}) {
    let id = params.id;
    if(!id) {
      throw IvalidArgumentException.invoke('Not found :id argument on router.');
    }
    let user = this.repository.select([{code: 1}, {name: 1}, {roles: 1}, {_id: 1}]).find(id)
    if(user) {
      let inputs = request.only(['code', 'name', 'roles'])
      if(!user.user_barcode) {
        inputs['user_barcode'] = await this.genBarcodeEan13()
      } else {
        inputs['user_barcode'] = user.user_barcode
      }
      if(!inputs.code) {
        inputs['code'] = user.code;
      }
      if(!inputs.roles) {
        inputs.roles = user.roles;
      }
      let rs = await this.repository.update(id, inputs)
      if(rs) {
        return response.apiSuccess(rs)
      } else {
        return response.apiNoContent()
      }

    } else {
      return response.apiNoContent()
    }
  }

  async destroy ({params, request, response}) {
    let id = params.id;
    if(!id) {
      throw IvalidArgumentException.invoke('Not found :id argument on router.')
    }
    let rs = await this.repository.delete(id);
    if(rs) {
      return response.apiSuccess();
    } else {
      return response.apiNoContent();
    }
  }

  getCheckNumberEAN(barcode, length = 13) {
    let size = barcode.length;
    if(size < length && size == 12) {
      let sumEvenIndexs = 0;
      let sumOddIndexs = 0;
      for(let i = 0; i < size; i++) {
        if(i % 2 == 0) {
          sumOddIndexs += parseInt(barcode.charAt(i))
        } else {
          sumEvenIndexs += parseInt(barcode.charAt(i))
        }
      }
      let sumIndexs = sumEvenIndexs * 3 + sumOddIndexs
      let n = sumIndexs % 10;

      return n == 0 ? 0 : 10 - n;
    } else {
      return null;
    }
  }

  async genBarcodeEan13() {
    let barcodePattern = '21';
    let year = String(Moment().year()).substring(2, 4)
    let month = String(Moment().month() + 1).padStart(2, '0');
    barcodePattern += year + month;
    let barcodeReg = new RegExp(barcodePattern + '[0-9]+');
    let lastBarcode = await this.repository.select([{user_barcode: 1}]).whereLike({user_barcode: barcodeReg}).orderBy({user_barcode: 'desc'}).first()
    if(lastBarcode) {
      let lastBarcodeSubStr = lastBarcode.user_barcode.substring(barcodePattern.length, 12);
      let newBarcodeSubStr = parseInt(lastBarcodeSubStr) + 1;
      newBarcodeSubStr = String(newBarcodeSubStr).padStart(6, '0');
      let barcode = barcodePattern + newBarcodeSubStr;
      let checkNum = this.getCheckNumberEAN(barcode);

      return barcode + checkNum;
    } else {
      let newBarcodeSubStr = String(1).padStart(6, '0')
      let barcode = barcodePattern + newBarcodeSubStr;
      let checkNum = this.getCheckNumberEAN(barcode)
      console.log(barcode + checkNum);
      return barcode + checkNum;
    }
  }
}

module.exports = UserController
