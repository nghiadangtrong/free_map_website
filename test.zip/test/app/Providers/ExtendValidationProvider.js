const { ServiceProvider } = require('@adonisjs/fold')
const Pluralize = require('pluralize')
class ExtendValidationProvider extends ServiceProvider {
  async subArrayOf (data, field, message, args, get) {
    const arrayValues = get(data, field)
    if (!arrayValues) {
      /**
       * skip validation if value is not defined. `required` rule
       * should take care of it.
       */
      return
    }
    if(arrayValues.length > 0 && args.length > 0) {
      let isSubArray = true;
      for(let value of arrayValues) {
        if(!args.includes(value)) {
          isSubArray = false;
          break;
        }
      }
      if(isSubArray) {
        return
      } else {
        throw message
      }
    } else if(args.length == 0) {
      return
    } else {
      throw message
    }
  }
  async arrayMaxLength (data, field, message, args, get) {
    const arrayValues = get(data, field)
    let [max] = args
    if(!arrayValues) {
      return
    } else {
      if(arrayValues.length >  max) {
        throw message
      } else {
        return
      }
    }
  }

  async arrayMinLength (data, field, message, args, get) {
    const arrayValues = get(data, field)
    let [min] = args
    if(!arrayValues) {
      return
    } else {
      if(arrayValues.length < min) {
        throw message
      } else {
        return
      }
    }
  }

  async arraySize (data, field, message, args, get) {
    const arrayValues = get(data, field)
    let [min, max] = args
    if(!arrayValues || arrayValues.length == 0) {
      return
    } else {
      if(arrayValues.length >= min && arrayValues.length <= max) {
        return
      } else {
        throw message
      }
    }
  }

  async hasAnyRole (data, field, message, args, get) {
    const Config = use('Config')
    const arrayRoles = get(data, field)
    let configRoles = await Config.get('permission.show_roles')
    configRoles = Object.keys(configRoles)
    let hasOneRole = false;
    if(!arrayRoles || arrayRoles.length == 0) {
      return
    } else {
      for(let role of arrayRoles) {
        if(configRoles.includes(role)) {
          hasOneRole = true;
          break;
        }
      }
      if(hasOneRole) {
        return 
      } else {
        throw message
      }
    }
  }

  async existsOnDb(data, field, message, args, get) {
    let value = get(data, field)
    let [collection, field] = args
    if(!value || !collection || !field) {
      return
    }else {
      if(Pluralize.isPlural(collection)) {
        collection = Pluralize.singular(collection)
      }
      collection = collection.charAt(0).toUpperCase() + collection.slice(1);
      let model = make('App/Models/' + collection)
      if(model) {
        if(Array.isArray(value)) {
          let countInDB = await model.whare('_id').in(value).count()
          if(countInDB == value.length) {
            return
          } else {
            throw message
          }
        } else if(value instanceof String || typeof value == 'string') {
          let doc = await model.findBy(field, value)
          if(doc) {
            return
          }else {
            throw message
          }
        }
      } else {
        return
      }
    }
  }
  async canDelete(data, field, message, args, get) {
    let fieldValue = this.ctx.request.params.id;
    let [collection, fieldname, ignoreField, ignoreValue] = args;
    if(!collection || !fieldname || !ignoreField || !ignoreValue || !fieldValue) {
      return
    } else {
      if(Pluralize.isPlural(collection)) {
        collection = Pluralize.singular(collection)
      }
      collection = collection.charAt(0).toUpperCase() + collection.slice(1);
      let model = make('App/Models/' + collection)
      if(model) {
        let conditions = {}
        conditions[fieldname] = fieldValue;
        conditions[ignoreField] = ignoreValue;
        let doc = await model.where(conditions).first()
        if(doc) {
          throw message
        } else {
          return
        }
      } else {
        return
      }
    }
  }

  async validBarcode (data, field, message, args, get) {
    let fieldValue = get(data, field)
    let [barcodeType] = args
    if(!fieldValue) {
      return
    } else {
      if(barcodeType === 'ean13') {
        if (fieldValue.length == 12) {
          return
        } else if (fieldValue.length == 13) {
          let valid = this.ctx.request.isEan13Barcode(fieldValue)
          if(valid) {
            return
          } else {
            return message
          }
        } else {
          return
        }
      }
    }
  }

  boot () {
    const Validator = use('Validator')
    Validator.extend('subArrayOf', this.subArrayOf.bind(this))
    Validator.extend('arraySize', this.arraySize.bind(this))
    Validator.extend('arrayMaxLength', this.arrayMaxLength.bind(this))
    Validator.extend('arrayMinLength', this.arrayMinLength.bind(this))
    Validator.extend('hasAnyRole', this.hasAnyRole.bind(this))
    Validator.extend('existsOnDb', this.existsOnDb.bind(this))
    Validator.extend('canDelete', this.canDelete.bind(this))
    Validator.extend('validBarcode', this.validBarcode.bind(this))
  }
}

module.exports = ExtendValidationProvider