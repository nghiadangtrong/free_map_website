const {ServiceProvider} = require('@adonisjs/fold')
class ExtendRequestProvider extends ServiceProvider {

  boot () {
	const Config = use('Adonis/Src/Config')
    const Request = use('Adonis/Src/Request')
    Request.macro('getPaginateParams', function () {
      let defaultValues = Config.get('repository.pagination');
      let {limit, page} = this.only(['limit', 'page']);
      limit = parseInt(limit);
      page = parseInt(page);
      if(!limit || limit == NaN || limit <= 0) {
      	limit = defaultValues.per_page;
      }

      if(!page || page == NaN || page <= 0) {
      	page = defaultValues.page;
      }

      return {limit, page}
    })

    Request.macro('getQueryFilters', function() {
      let decodeQueries = this._qs;
      delete decodeQueries['page'];
      delete decodeQueries['limit'];
      return decodeQueries
    })

    Request.macro('isEan13Barcode', function(barcode) {
      sumEvenIndexs = 0;
      sumOddIndexs = 0;
      if(barcode.length == 13) {

        let size = barcode.length;
        for(let i = 0; i < size - 1; i--) {
          if(i % 2 == 0) {
            sumOddIndexs += parseInt(barcode.charAt(i))
          } else {
            sumEvenIndexs += parseInt(barcode.charAt(i))
          }
        }
        let sumIndexs = sumEvenIndexs * 3 + sumOddIndexs;
        let n = sumIndexs % 10;
        let checknumber = n == 0 ? 0 : 10 - n;
        if(checknumber == parseInt(barcode.charAt(size - 1))) {
          return true
        } else {
          return false
        }
      } else {
        return true
      }
    })
  }

  * register () {
    // register bindings
  }

}
module.exports = ExtendRequestProvider