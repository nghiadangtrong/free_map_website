const { ServiceProvider } = require('@adonisjs/fold')

class ExtendResponseProvider extends ServiceProvider {
  boot () {
    const Response = use('Adonis/Src/Response')

    // status 2xx
    Response.macro('apiSuccess', function (data, message) {
      this.status(200).header('message', message || 'OK').json(data)
    })

    Response.macro('apiCreated', function (item, message) {
      this.status(201).header('message', message || 'Created').json(item)
    })

    Response.macro('apiAccepted', function(message) {
      this.status(202).header('message', message || 'Accepted').json({});
    })

    Response.macro('apiNoContent', function(message) {
      this.status(204).header('message', message || 'No Content').json({})
    })

    // Status 3xx
    
    Response.macro('apiMovePermanently', function(message) {
      this.status(301).header('message', message || 'Moved Permanently' ).json({})
    })

    Response.macro('apiFound', function(message) {
      this.status(302).header('message', message).json({})
    })

    Response.macro('apiSeeOther', function(message) {
      this.status(303).header('message', message || 'See others').json({})
    })

    Response.macro('apiNotModified', function(message) {
      this.status(304).header('message', message || 'Not Modified').json({})
    })

    Response.macro('apiTemporaryRedirect', function(url, message) {
      this.status(307).header('message', message || 'Temporary Redirect').json({
        url: url || '/'
      })
    })

    // status 4xx

    Response.macro('apiBadRequest', function(message) {
      this.status(400).header('message', message || 'Bad Request').json({})
    })

    Response.macro('apiUnauthorized', function(message) {
      this.status(401).header('message', message || 'Unauthorized').json({})
    })

    Response.macro('apiForbidden', function(message) {
      this.status(403).header('message', message || 'Forbidden').json({})
    })

    Response.macro('apiNotFound', function(message) {
      this.status(404).header('message', message || 'Not Found.').json({})
    })

    Response.macro('apiMethodNotAllow', function(message) {
      this.status(405).header('message', message || 'Method Not Allowed').json({})
    })

    Response.macro('validateFailed', function (errorMessages, message) {
      this.status(422).header('message', message || 'Validation failed',).json({
        errors: errorMessages
      })
    })

    // Status 5xx
    
    Response.macro('apiServerError', function(message) {
      this.status(500).header('message', message || 'Internal Server Error').json({})
    })


  }
}

module.exports = ExtendResponseProvider