'use strict'

class CreateFormat {
  get validateAll () {
  	return true;
  }
  
  get rules () {
    return {
      name: 'required|string|min:3|max:30',
      description: 'string|min:5:max: 100',
      config: 'required'
    }
  }

  async fails (errorMessages) {
    return this.ctx.response.status(422).header('message', 'Validation failed.').json({
      errors: errorMessages
    })
  }
}

module.exports = ReportFormat\CreateFormat
