'use strict'
const Trans = use('Antl')

class CreateAllergy {

  get validateAll () {
  	return true;
  }

  get data () {
    let requestBody = this.ctx.request.all()

    if(!requestBody.name) {
      requestBody['name'] = '';
    }

    if(!requestBody.materialIds) {
      requestBody['materialIds'] = []
    }

    return requestBody;
  }

  get rules () {
    return {
      code: 'string|min:6|max:8|unique:allergies,code',
      name: 'required|string|min:2|max:20',
      materialIds: 'required|array|array_min_length:2|exists_on_db:materials,_id'
    }
  }

  get messages () {
    let defaultLocales = ['en', 'ja'];
    
    let locale = this.ctx.request.header('Accept-Language')
    let validationMsg = {}
    if(locale && defaultLocales.includes(locale)) {
      validationMsg = Trans.forLocale(locale).get('validation.allergy')
    } else {
      validationMsg = Trans.get('validation.allergy')
    }
    return {
      'name.required': validationMsg.required.name,
      'code.unique': validationMsg.unique.code,
      'code.min': validationMsg.min.code,
      'code.max': validationMsg.max.code,
      'name.min': validationMsg.min.name,
      'name.max': validationMsg.max.name,
      'materialIds.array_min_length': validationMsg.min.materials,
      'materialIds.exists_on_db': validationMsg.exist_on_db.materials
    }
  }

  async fails (errorMessages) {
    return this.ctx.response.status(422).header('message', 'Validation failed.').json({
      errors: errorMessages
    })
  }
}

module.exports = CreateAllergy
