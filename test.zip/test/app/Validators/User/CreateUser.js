'use strict'
const Config = use('Config')
const Trans = use('Antl')

class CreateUser {
  get validateAll () {
  	return true
  }

  get data () {
    let requestBody = this.ctx.request.all()
    if(!requestBody.code) {
      requestBody['code'] = '';
    }

    if(!requestBody.name) {
      requestBody['name'] = '';
    }

    if(!requestBody.password) {
      requestBody['password'] = '';
    }

    if(!requestBody.password_confirmation) {
      requestBody['password_confirmation'] = '';
    }

    if(!requestBody.roles) {
      requestBody['roles'] = [];
    }


    return requestBody;
  }

  get rules () {
    let configRoles = Config.get('permission.roles') 
    let user_roles = Object.keys(configRoles).toString();
    return {
      code: 'required|max:8|min:6|string|unique:users,code',
      name: 'required|max:30|min:3|string',
      password: 'required|min:6|string|confirmed',
      roles: 'required|array|has_any_role|array_size:1,1'
    }
  }

  get messages() {
    let defaultLocales = ['en', 'ja'];
    let locale = this.ctx.request.header('Accept-Language')
    let configRoles = Config.get('permission.roles') 
    let user_roles = Object.keys(configRoles).toString()
    let validationMsg = {}
    if(locale && defaultLocales.includes(locale)) {
      validationMsg = Trans.forLocale(locale).get('validation.user')
    } else {
      validationMsg = Trans.get('validation.user')
    }
    return {
      'name.required': validationMsg.required.name,
      'password.required': validationMsg.required.password,
      'roles.required': validationMsg.required.roles,
      'code.unique': validationMsg.unique.code,
      'code.min': validationMsg.min.code,
      'code.max': validationMsg.max.code,
      'name.min': validationMsg.min.name,
      'name.max': validationMsg.max.name,
      'password.min': validationMsg.min.password,
      'password.confirmed': validationMsg.confirmed.password,
      'roles.has_any_role': validationMsg.has_any_role.roles
    }
  }

  async fails (errorMessages) {
    return this.ctx.response.status(422).header('message', 'Validation failed.').json({
    	errors: errorMessages
    })
  }
}

module.exports = CreateUser
