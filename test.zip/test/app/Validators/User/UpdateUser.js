'use strict'

const Config = use('Config')
const Trans = use('Antl')

class UpdateUser {
  get validateAll () {
  	return true
  }

  get data () {
    let requestBody = this.ctx.request.all()
    if(!requestBody.name) {
      requestBody['name'] = '';
    }

    return requestBody;
  }
  
  get rules () {
  	let userID = this.ctx.params.id
    return {
      code: `unique:users,code,_id,${userID}`,
      name: 'required|max:30|min:3',
      roles: 'array|array_size:1,1|has_any_role'
    }
  }
  // custom messages when validation fail.
  get messages() {
    let defaultLocales = ['en', 'ja'];
    let locale = this.ctx.request.header('Accept-Language')
    let configRoles = Config.get('permission.show_roles') 
    let user_roles = Object.keys(configRoles).toString()
    let validationMsg = {}
    if(locale && defaultLocales.includes(locale)) {
      validationMsg = Trans.forLocale(locale).get('validation.user')
    } else {
      validationMsg = Trans.get('validation.user')
    }
    
    return {
      'name.required': validationMsg.required.name,
      'code.unique': validationMsg.unique.code,
      'code.min': validationMsg.min.code,
      'code.max': validationMsg.max.code,
      'name.min': validationMsg.min.name,
      'name.max': validationMsg.max.name,
      'roles.has_any_role': validationMsg.has_any_role.roles
    }
  }

  async fails (errorMessages) {
    return this.ctx.response.status(422).header('message', 'Validation failed.').json({
    	errors: errorMessages
    })
  }
}

module.exports = UpdateUser
