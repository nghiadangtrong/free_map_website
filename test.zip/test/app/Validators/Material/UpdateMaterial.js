'use strict'
const Trans = use('Antl')

class UpdateMaterial {
  get validateAll () {
  	return true;
  }

  get data () {
    let requestBody = this.ctx.request.all()
    if(!requestBody.name) {
      requestBody['name'] = '';
    }

    return requestBody;
  }

  get rules () {
  	let materialID = this.ctx.params.id;
    return {
      code: `string|min:6|max:8|unique:materials,code,_id,${materialID}`,
      name: 'required|string|min:1|max:30',
      barcode: `string|valid_barcode:ean13|unique:materials,barcode,_id,${materialID}`
    }
  }

  get messages () {
    let defaultLocales = ['en', 'ja'];
    let locale = this.ctx.request.header('Accept-Language')
    let validationMsg = {}
    if(locale && defaultLocales.includes(locale)) {
      validationMsg = Trans.forLocale(locale).get('validation.material')
    } else {
      validationMsg = Trans.get('validation.material')
    }
    
    return {
      'name.required': validationMsg.required.name,
      'code.min': validationMsg.min.code,
      'code.max': validationMsg.max.code,
      'name.min': validationMsg.min.name,
      'name.max': validationMsg.max.name,
      'barcode.valid_barcode': validationMsg.valid_barcode.barcode,
      'code.unique': validationMsg.unique.code,
      'barcode.unique': validationMsg.unique.barcode
    }
  }

  async fails (errorMessages) {
    return this.ctx.response.status(422).header('message', 'Validation failed.').json({
      errors: errorMessages
    })
  }
}

module.exports = UpdateMaterial
