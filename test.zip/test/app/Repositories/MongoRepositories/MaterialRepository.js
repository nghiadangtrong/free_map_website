'use strict'

const BaseRepository = use('App/Repositories/MongoRepositories/BaseRepository');

class MaterialRepository extends BaseRepository {
	constructor () {
		super();
	}

	get modelClass () {
	  return 'App/Models/Material'
	}

	get searchable () {
		return ['code', 'name', 'barcode']
	}
}

module.exports = MaterialRepository