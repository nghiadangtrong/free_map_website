'use strict'

const BaseRepository = use('App/Repositories/MongoRepositories/BaseRepository');

class AllergyRepository extends BaseRepository {

	constructor () {
		super();
	}

	get modelClass () {
	  return 'App/Models/Allergy';
	}

	get searchable () {
    return ['code', 'name'];
	}

	


}

module.exports = AllergyRepository