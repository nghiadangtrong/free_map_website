'use strict'

const BaseRepository = use('App/Repositories/MongoRepositories/BaseRepository');

class ReportFormatRepository extends BaseRepository {
	constructor () {
		super();
	}

	get modelClass () {
	  return 'App/Models/ReportFormat'
	}

	get searchable () {
		return ['name', 'description']
	}
}

module.exports = ReportFormatRepository