'use strict'

const BaseRepository = use('App/Repositories/MongoRepositories/BaseRepository');

class ProductRepository extends BaseRepository {
	constructor () {
		super();
	}

	get modelClass () {
	  return 'App/Models/Product'
	}

	get searchable () {
		return ['code', 'name']
	}
}

module.exports = ProductRepository