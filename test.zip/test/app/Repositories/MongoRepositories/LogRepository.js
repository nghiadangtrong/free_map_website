'use strict'

const BaseRepository = use('App/Repositories/MongoRepositories/BaseRepository');

class LogRepository extends BaseRepository {
	constructor () {
		super();
	}

	get modelClass () {
	  return 'App/Models/Log'
	}

	get searchable () {
		return [];
	}
}

module.exports = LogRepository