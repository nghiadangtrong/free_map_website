'use strict'

class BaseRepository {
    constructor() {
        this.model = null;
        this.query = null;
        this.withs = [];
        this.selectedColumns = '';
        this.makeModel()
        this.boot()
        this.orderColumns = {}
    }

    get searchable() {
        return [];
    }

    get modelClass () {
        throw new Error('modelClass getter missing')
    }

    boot() {

    }

    makeModel () {
        this.model = make(this.modelClass)
        this.query = this.model.query()
        return this.model
    }

    newQuery(skipOrderBy = false) {
        this.query = this.model.query()
        if(skipOrderBy === false) {
            this.query.sort(this.orderColumns)
        }

        return this
    }

    orderBy(cols) {
        let sort = {};
        if(typeof cols == 'object') {
            cols = Object.entries(cols);
            for(let i = cols.length - 1; i >= 0; i--) {
                let [colname, direction] = cols[i];
                if(['DESC', 'desc', -1].includes(direction)) {
                    sort[colname] = 'desc';
                }else {
                    sort[colname] = 'asc';
                }
            }
        } else {
            sort[col] = 'desc'
        }
        this.query = this.query.sort(sort);

        return this
    }

    select (columns) {
        let selectedCol = '';
        for(let column of columns) {
            if(typeof column === 'string' || column instanceof String) {
                selectedCol += column + ' ';
            } else if (typeof column === 'object' || column instanceof Object) {
                let [colname, include] = Object.entries(column)[0];
                if(include != 0) {
                    selectedCol += colname + ' ';
                }else {
                    selectedCol += '-' + colname + ' ';
                }
            }
        }
        selectedCol = selectedCol.trim()
        this.query = this.query.select(selectedCol)

        return this;
    }

    async first() {
        let doc = await this.query.first()

        return doc;
    }

    async all () {
        let docs = await this.query.fetch()

        return docs;
    }

    async paginate (page, limit = 30) {
        let skip = (page - 1) * limit;
        let docs = await this.query.sort().limit(limit).skip(skip).fetch()
        let aggregate = await this.query.select({}).count();
        let last_page = (aggregate % limit == 0) ? parseInt(aggregate / limit) : parseInt(aggregate / limit) + 1;
        let paginateData = {
            total: aggregate || 0,
            perPage: limit,
            lastPage: last_page,
            page: page,
            data: docs || []
        };

        return paginateData;
    }

    async findBy(field, value) {
        this.newQuery()
        let doc = await this.query.where(field).eq(value).first()

        return doc;
    }

    async find (id) {
        let doc = await this.query.where({_id: id}).first()

        return doc;
    }

    where(conditions) {
        this.query = this.query.where(conditions);

        return this;
    }

    whereIn(field, values) {
        this.query = this.query.where(field).in(values);

        return this;
    }

    whereBetween (field, from, to) {
        this.query = this.query.where(field).gte(from).lte(to);

        return this;

    }

    whereInMultiple(conditions) {
        for(let i = conditions.length - 1; i >= 0; i--) {
            let field = conditions[i].field || conditions[i][0];
            let values = condtions[i].values || conditions[i][1];
            if(field && values && values.length > 0) {
                this.query = this.query.where(field).in(values);
            }
        }

        return this;
    }

    whereLike(conditions) {
        if(conditions instanceof Object) {
            for(let field of Object.keys(conditions)) {
                if(!conditions[field] instanceof RegExp) {
                    conditions[field] = new RegExp(conditions[field])
                }
            }
            this.query = this.query.where(conditions)
        }

        return this
    }
    async create(inputs) {
        let doc = await this.model.create(inputs);
        if(doc) {
            return doc;
        } else {
            return 0;
        }
    }

    async update (id, inputs) {
        let doc = await this.model.find(id);
        console.log(doc)
        if(doc) {
            doc.merge(inputs);
            await doc.save();
            return doc;
        } else {
            return 0;
        }

    }

    async updateByConditions(inputs, conditions) {
        let docs = await this.where(conditions).all();
        if(docs.length) {
            for (let i = docs.length - 1; i >= 0; i--) {
                docs[i].merge(inputs);
                await docs[i].save();
            }
            return docs.length;
        } else {
            return 0;
        }
    }

    async delete (id) {
        let doc = await this.find(id);
        if(doc) {
            doc.delete();
            return doc;
        } else {
            return 0;
        }
    }

    async deleteByConditions(conditions) {
        const docs = await this.where(conditions).all();
        if(!docs.length) {
            return 0;
        }
         for (let i = docs.length - 1; i >= 0; i--) {
            await docs[i].delete();
        }

        return docslength;
    }

    async count(groupByField = null) {
        let countDoc = 0;
        if(groupByField) {
            countDoc = await this.query.count(groupByField);
        } else {
            countDoc = await this.query.count();
        }

        return countDoc;
    }

    with (relations) {
        for(let relation of relations) {
            if(!this.withs.includes(relation)) {
                this.withs.push(relation)
            }
        }
        this.query = this.query.with(this.withs)

        return this;
    }

    searchAll(keyword) {
        if(typeof keyword === 'string' || keyword instanceof String) {
            keyword = keyword.trim()
        } else if(typeof keyword == 'object' || keyword instanceof Object) {
            keyword = Object.values(keyword)[0];
        }
        if(this.searchable.length > 0 && keyword && keyword != '') {
            keyword = new RegExp(keyword)
            let conditions = []
            for(let field of this.searchable) {
                let cond = {}
                cond[field] = keyword
                conditions.push(cond)
            }
            this.query = this.query.where({$or: conditions})
        }

        return this
    }
    /**
     * hàm sử dụng cho thư viện BootStrap Table 2 (Next)
     * tương thích với filters, paginate.
     * @param {*} params
     * @param {*} column
     */
    getForTableNext(params, column = null){
        let filters = params.filters ? JSON.parse(params.filters) : {} //lấy giá trị filters của table
        let page = parseInt(params.page) || 1 //khởi tạo số page hiện tại của table
        let limit = parseInt(params.sizePerPage) || 10 //số item/trang
        let conditions = this._buildFilterCondition(filters)
        return this.where(conditions).paginate(page, limit) //sử dụng hàm paginate để phân trang.

    }
    /**
     * hàm xây dựng condition cho getForTableNext
     * @param {*} filters
     */
    _buildFilterCondition(filters){
        let fields = Object.keys(filters)

        let conditions = {};
        fields.forEach((field, i) =>{ //foreach từng field trong condition gửi lên
            let dataFilter = filters[field]
            switch (dataFilter.comparator){
                case "LIKE": //xử lý cho điều kiện like. điều kiện này config trên client.
                if(!(dataFilter.filterVal instanceof RegExp)) {
                    let caseSensitive = dataFilter.caseSensitive ? '': 'i' //kiểm tra có phân biệt hoa thường hay không
                    conditions[field] = new RegExp(dataFilter.filterVal.trim(), caseSensitive)
                }
                break
                default: //xử lý cho điều kiện bằng.
                    conditions[field] = dataFilter.filterVal
                break;
            }
        })
        return conditions
    }

}
module.exports = BaseRepository
