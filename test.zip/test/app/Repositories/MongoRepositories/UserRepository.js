'use strict'

const BaseRepository = use('App/Repositories/MongoRepositories/BaseRepository');

class UserRepository extends BaseRepository {
	constructor () {
		super();
	}

	get modelClass () {
	  return 'App/Models/User'
	}
	get searchable () {
		return ['code', 'name']
    }

}

module.exports = UserRepository
